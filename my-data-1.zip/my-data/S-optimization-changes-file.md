w3speedup2018 Shopify Account:
w3speedup2018@gmail.com
Support@12332

Kamalkant Shopify Account:
kamalkj9460@gmail.com
jX`-zQT6!pUwmQ9e

Sunil Shopify Account
sunilsainiseo97@gmail.com
support@123;Aw3

Sunil Google Account
sunilsainiseo97@gmail.com
Sunil@1234

Rohitash Shopify Account
rohitashs345@gmail.com
dwN>V5wLVZe>95}v

Rohitash Google Account
rohitashs345@gmail.com
listen@#$10

Support Shopify Account
support@w3speedup.com
support@123

Meenakshi Shopify / Google account
meenkshi.nahar@gmail.com
meenakshi@123

w3speedup01@gmail.com
4G]r=",2)msC93]z

Vikas R Gupta Shopify Account:
vikaskrgupta25@gmail.com
W3@Wordpress$

Vikas R Gupta Google Account:
vikaskrgupta25@gmail.com
W3@Wordpress$

Chitransh shopify account
jainchitransh28@gmail.com
affiliate@1234

https://cloud.w3speedup.com/optimize/css/shopify.php?url=https://nudress.com/&key=NdiKtIFZo8M8OA1g

#content_for_header Replace
{%- if request.design_mode or template contains 'cart' or template contains 'checkout' -%}
	{{ content_for_header }}
    {%- else -%}
	{% capture content_for_header2 %}{{ content_for_header }}{% endcapture %}
	{{ content_for_header2 | replace: ' defer="defer" ', ' type="lazyload2" ' | replace: " src=", " data-src=" | replace: "window.addEventListener('load', asyncLoad, false);", "window.addEventListener('wnw_load', asyncLoad, false);" | replace: "DOMContentLoaded", "DOMContentLoaded2" }}
	<script>var trekkie=[];trekkie.integrations=!0;window.BOOMR={},window.BOOMR.version=true;</script>
{%- endif -%}

#Separate critical css
{% if template contains "index" %}
	{% render "index-css" %}
{% elsif template contains "collection" %}
	{% render "collection-css" %}
{% elsif template contains "product" %}
	{% render "product-css" %}
{% else %}
	{% render "critical-css" %}
{% endif %}

#Include WNW Opt.file in theme.liquid
{{ 'wnw-optimization.js' | asset_url | script_tag }}


#Replace code if Judge review is used
<link rel="dns-prefetch" href="https://cdn.judge.me/">
{{ shop.metafields.judgeme.settings }}
{% for count in (0..5) %}
	{% assign metafield_key = 'html_miracle_' | append: count %}
	{% assign current_metafield = shop.metafields.judgeme[metafield_key] %}
	{% unless current_metafield %} {% break %} {% endunless %}
	{{ current_metafield }}
{% endfor %}
<script data-cfasync="false" type="lazyload2" data-src="https://cdn.judge.me/shopify_v2.js"></script>
<link rel="stylesheet" data-href="https://cdn.judge.me/shopify_v2.css">
<script type="lazyload2">
    setTimeout(function() {
        var d = document,
        e = d.createEvent('Event');
        e.initEvent('jdgm.doneLoadingCss', !0, !0), d.dispatchEvent(e)
    });
</script>
<noscript><link rel="stylesheet" type="text/css" media="all" href="https://cdn.judge.me/shopify_v2.css"></noscript>


#Menu Click
<script>
	var site_nav_link_burger = true;
	jQuery(document).ready(function() {
		jQuery(".fa-bars").click(function() {
			if(site_nav_link_burger) {
				event.preventDefault();
				site_nav_link_burger = false;
			}
		});
	})
</script>

function fullJSLoadedCB() {
	setTimeout(function() {
		if(site_nav_link_burger == false) {
			jQuery(".mobile-nav-toggle").click();
			site_nav_link_burger = false;
		}
	});
}

#Menu Click two


<script>
	var site_nav_link_burger = true;
    document.addEventListener("DOMContentLoaded", function() {
		jQuery(".navbar-toggle").on("click", function() {
            console.log("site-header-menu-toggle clicked");
			if(site_nav_link_burger) {
				event.preventDefault();
				site_nav_link_burger = false;
			}
		});
	})
</script>

function fullJSLoadedCB() {
	setTimeout(function() {
		if(site_nav_link_burger == false) {
            console.log("2");
			jQuery(".navbar-toggle").click();
			site_nav_link_burger = false;
		}
	}, 1000);
}

#Video Play
<script type="lazyload2">
		setTimeout(function() {
            var lazyVideos = document.querySelectorAll("video");
            lazyVideos.forEach(function(lazyVid) {
              lazyVid.load();
              lazyVid.muted= true;
              lazyVid.play();
            });
		});
</script>





shogun
pagefly
zipify
gempage
globo

<img
	src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
	{% if rimg_format == '' %}
		data-src="{{ img | img_url: rimg_size, crop: crop }}"
	{% else %}
		data-src="{{ img | img_url: rimg_size, crop: crop, format: rimg_format }}"
	{% endif %}
	data-srcset="{{ rimg_density_srcset }}"
    alt="{{ rimg_alt }}"
	draggable="false" 
    class="{% if class != blank %}{{ class }}{% endif %} lazy2 lazy3"
    {% if style != blank %}style="{{ style }}"{% endif %}
    {% if attr != blank %}{{ attr }}{% endif %}
  >
{% endif %}


{%- if type.size > 0 -%}
  {% assign image_box_ratio = type.height | append: ".0" | times: 1 | divided_by: type.width | times: 100 | append: "%" %}
  {% assign img_url = type | img_url: '1x1' | replace: '_1x1.', '_{width}x.' %}

  <div class="box-ratio" style="padding-bottom: {{ image_box_ratio }};">
     class="lazyloaded lazy2 lazy3 {{ is_first }}"
      id="{{ type.id }}"
      data-src="{{ type | img_url: '1512x' }}"
      data-mobsrc="{{ type | img_url: '540x' }}"
      dat<imga-sizes="auto"
      {%- if data_widths != blank -%}data-widths="{{ data_widths }}"{%- endif -%}
      width="{{ type.width }}"
      height="{{ type.height }}"
      alt="{{ type.alt | escape }}">
  </div>
{%- endif -%}



    setTimeout(function(){
    jQuery('.slider-revolution').initRevolution()
    });
	
	
	
	
	<img class="boost-pfs-filter-product-item-main-image lazyloaded Image--lazyLoaded lazy2 lazy3"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="  
			data-src="{{- preview_image | img_url: '720x' -}}"
            data-mobsrc="{{- preview_image | img_url: '360x' -}}" 
			alt="{{- product.title | escape -}}"
			 />
			 
			 
			 @media(max-width:767px){.slideshow .slick-track .slick-active{display:block!important;z-index:9999!important;}}
			 
			 
			 
			 
            {%- if request.design_mode or template contains 'cart' or template contains 'checkout' -%}
            	{{ content_for_layout }}
            {%- else -%}
            	{% capture content_for_layout2 %}{{ content_for_layout }}{% endcapture %}
            	{{ content_for_layout2 | replace: '<iframe src="https://www.youtube.com/', '<iframelazy data-class="LazyLoad" data-src="https://www.youtube.com/'  }}
            {%- endif -%}
			
			
			
	  <script>
      	var site_nav_link_burger = true;
      	document.addEventListener("DOMContentLoaded", function() {
            var icon_menu = document.querySelector(".mobile-nav-bar .mobile-nav-item");
            icon_menu.addEventListener("click", function() {
      			if(site_nav_link_burger) {
      				event.preventDefault();
      				site_nav_link_burger = false;
      			}
      		});
      	})
      </script>
	  
	  
	  {% if forloop.first == true %} lazy3 {% endif %}
	  

{% if canonical_url contains '/account/register' or canonical_url contains '/pages/buy-back-page' %}

{% else %}

{% endif %}


    {% if template contains "collection" %}
    	
    {% else %}
    	
    {% endif %}
	
	
	{% if template contains 'page' or template contains 'checkout' %}
    	
    {% else %}
    	
    {% endif %}
	
	jQuery('.header__icon').click();
	
	
	
	
	        {%- if request.design_mode or template contains 'cart' or template contains 'checkout' -%}
            	{{ content_for_layout }}
            {%- else -%}
            	{% capture content_for_layout2 %}{{ content_for_layout }}{% endcapture %}
            	{{ content_for_layout2 | replace: '<link href="//cdn1.stamped.io', '<link data-href="//cdn1.stamped.io'  }}
            {%- endif -%}
			
			
			{%- if request.design_mode or template contains 'cart' or template contains 'checkout' -%}
            	{{ content_for_layout }}
            {%- else -%}
            	{% capture content_for_layout2 %}{{ content_for_layout }}{% endcapture %}
            	{{ content_for_layout2 | replace: 'href="https://www.youtube.com/', 'href="https://www.youtube.com/'  }}
            {%- endif -%}
			
			href="https://www.youtube.com/
	
			
	function lazyLoadVideo() {
	lazyVideo = document.querySelectorAll("source");
	lazyVideo.forEach(function(a) {
		if (a.dataset.src != null && a.dataset.src != "") {
			a.src = a.dataset.src;
			delete a.dataset.src;
        	lazyVideo2 = document.querySelectorAll("video");
        	lazyVideo2.forEach(function(b) {
                  b.load();
                  b.play();
        	});
		}
	});
}

@font-face {
font-family: 'icomoon';
src: url('') format('woff2');
font-weight: normal;
font-style: normal;
font-display:swap;	
}

<style>@media(min-width:1200px){div#shopify-section-header>.aph_bar_bar2:first-child{height:39px;background:#e11646}#shopify-section-header .aph_bar_bar{height:39px!important;visibility:visible!important;background:#e11646;margin-top:0!important}}@media(max-width:767px){div#shopify-section-header>.aph_bar_bar2:first-child{height:50.78px;background:#e11646}#shopify-section-header .aph_bar_bar{height:50.78px!important;visibility:visible!important;background:#e11646;margin-top:0!important}}</style>

<script>
        document.addEventListener("DOMContentLoaded", function() {
              var site_nav_link_burger = true;
              var w3_menu = document.querySelector('.header__icon--menu span .icon.icon-hamburger');
              var w3_menu_close = document.querySelector('.header__icon--menu span .icon.icon-close');
          if(site_nav_link_burger) {
            w3_menu.addEventListener("click", function(){
                      document.querySelector('.menu-drawer-container').classList.add("menu-opening");
                      document.querySelector('.menu-drawer-container').setAttribute("open", "");
                      event.preventDefault();
            });
            w3_menu_close.addEventListener("click", function(){				
                      document.querySelector('.menu-drawer-container').classList.remove("menu-opening");
                      document.querySelector('.menu-drawer-container').removeAttribute("open", "");
                      event.preventDefault();
              site_nav_link_burger = false;
            });
          }
        });
        </script>  
		
		
		.slide-show .slideshow-slider:not(.slick-initialized) > div:nth-child(n+2) {
    display: none;
}




  	  <script>
      	var site_nav_link_burger = true;
      	document.addEventListener("DOMContentLoaded", function() {
            var clickmenu = document.querySelector(".push_side.push-menu-btn");
            clickmenu.addEventListener("click", function() {
                console.log("first");
      			if(site_nav_link_burger) {
      				event.preventDefault();
      				site_nav_link_burger = false;
      			}
      		});
      	})
      </script>
	  
	  
	  function fullJSLoadedCB() {
	    setTimeout(function() {
        console.log("second");
		if(site_nav_link_burger == false) {
			jQuery("#SiteNavParent button").click();
			site_nav_link_burger = false;
		}
	},2000);
}



{% render "head-opt-files" %}
<style id="w3_bg_load">div:not(.w3_bg), section:not(.w3_bg), iframelazy:not(.w3_bg){background-image:none !important;}</style>
<script>var w3_lazy_load_by_px=200,blank_image_webp_url="https://d2pk8plgu825qi.cloudfront.net/wp-content/uploads/blank.pngw3.webp",google_fonts_delay_load=1e4,w3_mousemoveloadimg=!1,w3_page_is_scrolled=!1,w3_lazy_load_js=1,w3_excluded_js=0;class w3_loadscripts{constructor(e){this.triggerEvents=e,this.eventOptions={passive:!0},this.userEventListener=this.triggerListener.bind(this),this.lazy_trigger,this.style_load_fired,this.lazy_scripts_load_fired=0,this.scripts_load_fired=0,this.scripts_load_fire=0,this.excluded_js=w3_excluded_js,this.w3_lazy_load_js=w3_lazy_load_js,this.w3_fonts="undefined"!=typeof w3_googlefont?w3_googlefont:[],this.w3_styles=[],this.w3_scripts={normal:[],async:[],defer:[],lazy:[]},this.allJQueries=[]}user_events_add(e){this.triggerEvents.forEach(t=>window.addEventListener(t,e.userEventListener,e.eventOptions))}user_events_remove(e){this.triggerEvents.forEach(t=>window.removeEventListener(t,e.userEventListener,e.eventOptions))}triggerListener_on_load(){"loading"===document.readyState?document.addEventListener("DOMContentLoaded",this.load_resources.bind(this)):this.load_resources()}triggerListener(){this.user_events_remove(this),this.lazy_scripts_load_fired=1,this.add_html_class("w3_user"),"loading"===document.readyState?(document.addEventListener("DOMContentLoaded",this.load_style_resources.bind(this)),this.scripts_load_fire||document.addEventListener("DOMContentLoaded",this.load_resources.bind(this))):(this.load_style_resources(),this.scripts_load_fire||this.load_resources())}async load_style_resources(){this.style_load_fired||(this.style_load_fired=!0,this.register_styles(),document.getElementsByTagName("html")[0].setAttribute("data-css",this.w3_styles.length),document.getElementsByTagName("html")[0].setAttribute("data-css-loaded",0),this.preload_scripts(this.w3_styles),this.load_styles_preloaded())}async load_styles_preloaded(){setTimeout(function(e){document.getElementsByTagName("html")[0].classList.contains("css-preloaded")?e.load_styles(e.w3_styles):e.load_styles_preloaded()},200,this)}async load_resources(){this.scripts_load_fired||(this.scripts_load_fired=!0,this.hold_event_listeners(),this.exe_document_write(),this.register_scripts(),this.add_html_class("w3_start"),"function"==typeof w3_events_on_start_js&&w3_events_on_start_js(),this.preload_scripts(this.w3_scripts.normal),this.preload_scripts(this.w3_scripts.defer),this.preload_scripts(this.w3_scripts.async),this.wnwAnalytics(),this.wnwBoomerang(),await this.load_scripts(this.w3_scripts.normal),await this.load_scripts(this.w3_scripts.defer),await this.load_scripts(this.w3_scripts.async),await this.execute_domcontentloaded(),await this.execute_window_load(),window.dispatchEvent(new Event("w3-scripts-loaded")),this.add_html_class("w3_js"),"function"==typeof w3_events_on_end_js&&w3_events_on_end_js(),this.lazy_trigger=setInterval(this.w3_trigger_lazy_script,500,this))}async w3_trigger_lazy_script(e){e.lazy_scripts_load_fired&&(await e.load_scripts(e.w3_scripts.lazy),e.add_html_class("jsload"),clearInterval(e.lazy_trigger))}add_html_class(e){document.getElementsByTagName("html")[0].classList.add(e)}register_scripts(){document.querySelectorAll("script[type=lazyload_int]").forEach(e=>{e.hasAttribute("data-src")?e.hasAttribute("async")&&!1!==e.async?this.w3_scripts.async.push(e):e.hasAttribute("defer")&&!1!==e.defer||"module"===e.getAttribute("data-w3-type")?this.w3_scripts.defer.push(e):this.w3_scripts.normal.push(e):this.w3_scripts.normal.push(e)}),document.querySelectorAll("script[type=lazyload_ext]").forEach(e=>{this.w3_scripts.lazy.push(e)})}register_styles(){document.querySelectorAll("link[data-href]").forEach(e=>{this.w3_styles.push(e)})}async execute_script(e){return await this.repaint_frame(),new Promise(t=>{let s=document.createElement("script"),a;[...e.attributes].forEach(e=>{let t=e.nodeName;"type"!==t&&"data-src"!==t&&("data-w3-type"===t&&(t="type",a=e.nodeValue),s.setAttribute(t,e.nodeValue))}),e.hasAttribute("data-src")?(s.setAttribute("src",e.getAttribute("data-src")),s.addEventListener("load",t),s.addEventListener("error",t)):(s.text=e.text,t()),null!==e.parentNode&&e.parentNode.replaceChild(s,e)})}async execute_styles(e){var t;let s;return t=e,void((s=document.createElement("link")).href=t.getAttribute("data-href"),s.rel="stylesheet",document.head.appendChild(s),t.parentNode.removeChild(t))}async load_scripts(e){let t=e.shift();return t?(await this.execute_script(t),this.load_scripts(e)):Promise.resolve()}async load_styles(e){let t=e.shift();return t?(this.execute_styles(t),this.load_styles(e)):"loaded"}async load_fonts(e){var t=document.createDocumentFragment();e.forEach(e=>{let s=document.createElement("link");s.href=e,s.rel="stylesheet",t.appendChild(s)}),setTimeout(function(){document.head.appendChild(t)},google_fonts_delay_load)}preload_scripts(e){var t=document.createDocumentFragment(),s=0,a=this;[...e].forEach(i=>{let r=i.getAttribute("data-src"),n=i.getAttribute("data-href");if(r){let d=document.createElement("link");d.href=r,d.rel="preload",d.as="script",t.appendChild(d)}else if(n){let l=document.createElement("link");l.href=n,l.rel="preload",l.as="style",s++,e.length==s&&(l.dataset.last=1),t.appendChild(l),l.onload=function(){fetch(this.href).then(e=>e.blob()).then(e=>{a.update_css_loader()}).catch(e=>{a.update_css_loader()})},l.onerror=function(){a.update_css_loader()}}}),document.head.appendChild(t)}update_css_loader(){document.getElementsByTagName("html")[0].setAttribute("data-css-loaded",parseInt(document.getElementsByTagName("html")[0].getAttribute("data-css-loaded"))+1),document.getElementsByTagName("html")[0].getAttribute("data-css")==document.getElementsByTagName("html")[0].getAttribute("data-css-loaded")&&document.getElementsByTagName("html")[0].classList.add("css-preloaded")}hold_event_listeners(){let e={};function t(t,s){!function(t){function s(s){return e[t].eventsToRewrite.indexOf(s)>=0?"w3-"+s:s}e[t]||(e[t]={originalFunctions:{add:t.addEventListener,remove:t.removeEventListener},eventsToRewrite:[]},t.addEventListener=function(){arguments[0]=s(arguments[0]),e[t].originalFunctions.add.apply(t,arguments)},t.removeEventListener=function(){arguments[0]=s(arguments[0]),e[t].originalFunctions.remove.apply(t,arguments)})}(t),e[t].eventsToRewrite.push(s)}function s(e,t){let s=e[t];Object.defineProperty(e,t,{get:()=>s||function(){},set(a){e["w3"+t]=s=a}})}t(document,"DOMContentLoaded"),t(window,"DOMContentLoaded"),t(window,"load"),t(window,"pageshow"),t(document,"readystatechange"),s(document,"onreadystatechange"),s(window,"onload"),s(window,"onpageshow")}hold_jquery(e){let t=window.jQuery;Object.defineProperty(window,"jQuery",{get:()=>t,set(s){if(s&&s.fn&&!e.allJQueries.includes(s)){s.fn.ready=s.fn.init.prototype.ready=function(t){if(void 0!==t)return e.scripts_load_fired?e.domReadyFired?t.bind(document)(s):document.addEventListener("w3-DOMContentLoaded",()=>t.bind(document)(s)):t.bind(document)(s),s(document)};let a=s.fn.on;s.fn.on=s.fn.init.prototype.on=function(){if("ready"==arguments[0]){if(this[0]!==document)return a.apply(this,arguments),this;arguments[1].bind(document)(s)}if(this[0]===window){function e(e){return e.split(" ").map(e=>"load"===e||0===e.indexOf("load.")?"w3-jquery-load":e).join(" ")}"string"==typeof arguments[0]||arguments[0]instanceof String?arguments[0]=e(arguments[0]):"object"==typeof arguments[0]&&Object.keys(arguments[0]).forEach(t=>{Object.assign(arguments[0],{[e(t)]:arguments[0][t]})[t]})}return a.apply(this,arguments),this},e.allJQueries.push(s)}t=s}})}async execute_domcontentloaded(){this.domReadyFired=!0,await this.repaint_frame(),document.dispatchEvent(new Event("w3-DOMContentLoaded")),await this.repaint_frame(),window.dispatchEvent(new Event("w3-DOMContentLoaded")),await this.repaint_frame(),document.dispatchEvent(new Event("w3-readystatechange")),await this.repaint_frame(),document.w3onreadystatechange&&document.w3onreadystatechange()}async execute_window_load(){await this.repaint_frame(),setTimeout(function(){window.dispatchEvent(new Event("w3-load"))},100),await this.repaint_frame(),window.w3onload&&window.w3onload(),await this.repaint_frame(),this.allJQueries.forEach(e=>e(window).trigger("w3-jquery-load")),window.dispatchEvent(new Event("w3-pageshow")),await this.repaint_frame(),window.w3onpageshow&&window.w3onpageshow()}exe_document_write(){let e=new Map;document.write=document.writeln=function(t){let s=document.currentScript,a=document.createRange(),i=s.parentElement,r=e.get(s);void 0===r&&(r=s.nextSibling,e.set(s,r));let n=document.createDocumentFragment();a.setStart(n,0),n.appendChild(a.createContextualFragment(t)),i.insertBefore(n,r)}}async repaint_frame(){return new Promise(e=>requestAnimationFrame(e))}static execute(){let e=new w3_loadscripts(["keydown","mousemove","touchmove","touchstart","touchend","wheel"]);e.load_fonts(e.w3_fonts),e.user_events_add(e),e.excluded_js||e.hold_jquery(e),e.w3_lazy_load_js||(e.scripts_load_fire=1,e.triggerListener_on_load());let t=setInterval(function e(s){null!=document.body&&(document.body.getBoundingClientRect().top<-30&&s.triggerListener(),clearInterval(t))},500,e)}wnwAnalytics(){document.querySelectorAll(".analytics").forEach(function(e){trekkie.integrations=!1;var t=document.createElement("script");t.innerHTML=e.innerHTML,e.parentNode.insertBefore(t,e.nextSibling),e.parentNode.removeChild(e)})}wnwBoomerang(){document.querySelectorAll(".boomerang").forEach(function(e){window.BOOMR.version=!1;var t=document.createElement("script");t.innerHTML=e.innerHTML,e.parentNode.insertBefore(t,e.nextSibling),e.parentNode.removeChild(e)})}}w3_loadscripts.execute();</script>

{% render "footer-opt-files" %}

<script>
    w3_bglazyload=1;(function(){var img=new Image();img.onload=function(){w3_hasWebP=!!(img.height>0&&img.width>0);};img.onerror=function(){w3_hasWebP=false;};})();function w3_events_on_end_js(){const lazy_bg_style=document.getElementById("w3_bg_load");lazy_bg_style.remove();w3_bglazyload=0;lazyloadimages(0);}
    function w3_start_img_load(){var top=this.scrollY;lazyloadimages(top);lazyloadiframes(top);}
    function w3_events_on_start_js(){var lazyvideos=document.getElementsByTagName("videolazy");convert_to_video_tag(lazyvideos);w3_start_img_load();}
    window.addEventListener("scroll",function(event){w3_start_img_load();},{passive:true});var w3_is_mobile=(window.matchMedia("(max-width: 767px)").matches?1:0);var win_width=screen.availWidth;var bodyRectMain={};bodyRectMain.top=1;setInterval(function(){lazyloadiframes(top);},8000);setInterval(function(){lazyloadimages(0);},3000);document.addEventListener("click",function(){lazyloadimages(0);});function getDataUrl(img1,width,height){var myCanvas=document.createElement("canvas");var ctx=myCanvas.getContext("2d");var img=new Image();myCanvas.width=parseInt(width);myCanvas.height=parseInt(height);ctx.drawImage(img,0,0);img1.src=myCanvas.toDataURL("image/png");}
    function lazyload_img(imgs,bodyRect,window_height,win_width){for(var i=0;i<imgs.length;i++){if(imgs[i].getAttribute("data-class")=="LazyLoad"){var elem=imgs[i],elemRect=imgs[i].getBoundingClientRect();if(elemRect.top!=0&&(elemRect.top-(window_height-bodyRect.top))<w3_lazy_load_by_px){compStyles=window.getComputedStyle(imgs[i]);if(compStyles.getPropertyValue("opacity")==0){continue;}
    if(elem.tagName=="IFRAMELAZY"){var elem=document.createElement("iframe");var index;for(index=imgs[i].attributes.length-1;index>=0;--index){elem.attributes.setNamedItem(imgs[i].attributes[index].cloneNode());}
    imgs[i].parentNode.replaceChild(elem,imgs[i]);}
    var src=elem.getAttribute("data-src")?elem.getAttribute("data-src"):elem.src;if(w3_is_mobile&&elem.getAttribute("data-mob-src")){src=elem.getAttribute("data-mob-src");}
    var srcset=elem.getAttribute("data-srcset")?elem.getAttribute("data-srcset"):"";if(!srcset){elem.onload=function(){this.setAttribute("data-done","Loaded");if(typeof(w3speedup_after_iframe_img_load)=="function"){w3speedup_after_iframe_img_load(this);}}
    elem.onerror=function(){if(this.getAttribute("data-mob-src")&&w3_is_mobile&&this.getAttribute("data-src")){this.src=this.getAttribute("data-src");}}}
    elem.src=src;if(srcset!=null&srcset!=""){elem.srcset=srcset;}
    delete elem.dataset.class;}}}}
    function w3_load_dynamic_blank_img(imgs){for(var i=0;i<imgs.length;i++){if(imgs[i].getAttribute("data-class")=="LazyLoad"){var blanksrc=imgs[i].src;if(typeof(blanksrc)!="undefined"&&blanksrc.indexOf("data:")==-1){if(imgs[i].getAttribute("width")!=null&&imgs[i].getAttribute("height")!=null){var width=parseInt(imgs[i].getAttribute("width"));var height=parseInt(imgs[i].getAttribute("height"));getDataUrl(imgs[i],width,height);}}}}}
    function convert_to_video_tag(imgs){const t=imgs.length>0?imgs[0]:"";if(t){delete imgs[0];var newelem=document.createElement("video");var index;for(index=t.attributes.length-1;index>=0;--index){newelem.attributes.setNamedItem(t.attributes[index].cloneNode());}
    newelem.innerHTML=t.innerHTML;t.parentNode.replaceChild(newelem,t);if(typeof(newelem.getAttribute("data-poster"))=="string"){newelem.setAttribute("poster",newelem.getAttribute("data-poster"));}
    convert_to_video_tag(imgs);}}
    function lazyload_video(imgs,bodyRect,top,window_height,win_width){for(var i=0;i<imgs.length;i++){var elem=imgs[i],elemRect=imgs[i].getBoundingClientRect();if(elemRect.top!=0&&(elemRect.top-(window_height-bodyRect.top))<w3_lazy_load_by_px){if(typeof(imgs[i].getElementsByTagName("source")[0])=="undefined"){lazyload_video_source(imgs[i],top,window_height,win_width,elemRect,bodyRect);}else{var sources=imgs[i].getElementsByTagName("source");for(var j=0;j<sources.length;j++){var source=sources[j];lazyload_video_source(source,top,window_height,win_width,elemRect,bodyRect);}}}}}
    function lazyload_video_source(source,top,window_height,win_width,elemRect,bodyRect){if(typeof source!="undefined"&&source.getAttribute("data-class")=="LazyLoad"){if(elemRect.top!=0&&(elemRect.top-(window_height-bodyRect.top))<w3_lazy_load_by_px){var src=source.getAttribute("data-src")?source.getAttribute("data-src"):source.src;var srcset=source.getAttribute("data-srcset")?source.getAttribute("data-srcset"):"";if(source.srcset!=null&source.srcset!=""){source.srcset=srcset;}
    if(typeof(source.getElementsByTagName("source")[0])=="undefined"){if(source.tagName=="SOURCE"){source.parentNode.src=src;source.parentNode.load();if(source.parentNode.getAttribute("autoplay")!==null){source.parentNode.play();}}else{source.src=src;source.load();if(source.getAttribute("autoplay")!==null){source.play();}}}else{source.parentNode.src=src;}
    delete source.dataset.class;source.setAttribute("data-done","Loaded");}}}
    function lazyload_imgbgs(imgbgs,bodyRect,window_height,win_width){for(var i=0;i<imgbgs.length;i++){var elem=imgbgs[i],elemRect=imgbgs[i].getBoundingClientRect(),offset=elemRect.top-bodyRect.top;if((elemRect.top-(window_height-bodyRect.top))<w3_lazy_load_by_px){elem.classList.add("w3_bg");}}}
    function lazyloadimages(top){var imgs=document.querySelectorAll("img[data-class=LazyLoad]");var imgbgs=document.querySelectorAll("div:not(.w3_js), section:not(.w3_js), iframelazy:not(.w3_js)");var sources=document.getElementsByTagName("video");var sources_audio=document.getElementsByTagName("audio");var bodyRect=document.body.getBoundingClientRect();var window_height=window.innerHeight;var win_width=screen.availWidth;if(typeof(load_dynamic_img)!="undefined"){w3_load_dynamic_blank_img(imgs);delete load_dynamic_img;}
    if(w3_bglazyload&&((bodyRect.top<50&&bodyRectMain.top==1)||Math.abs(bodyRectMain.top)-Math.abs(bodyRect.top)<-50||Math.abs(bodyRectMain.top)-Math.abs(bodyRect.top)>50)){bodyRectMain=bodyRect;lazyload_imgbgs(imgbgs,bodyRect,window_height,win_width);}
    lazyload_img(imgs,bodyRect,window_height,win_width);lazyload_video(sources,bodyRect,top,window_height,win_width);lazyload_video(sources_audio,bodyRect,top,window_height,win_width);}
    lazyloadimages(0);function lazyloadiframes(top){var bodyRect=document.body.getBoundingClientRect();var window_height=window.innerHeight;var win_width=screen.availWidth;var iframes=document.querySelectorAll("iframelazy[data-class=LazyLoad]");lazyload_img(iframes,bodyRect,window_height,win_width);}
</script>   

type="lazyload_int"


		{%- if request.design_mode or template contains 'cart' or template contains 'checkout' -%}
    		{{ content_for_header }}
		{%- else -%}
        	{% capture content_for_header2 %}{{ content_for_header }}{% endcapture %}
    		{{ content_for_header2 | replace: ' defer="defer" ', ' type="lazyload_int" ' | replace: " src=", " data-src="| replace: "DOMContentLoaded", "w3-DOMContentLoaded" | replace: "window.addEventListener('load', asyncLoad, false);", "window.addEventListener('w3-DOMContentLoaded', asyncLoad, false);" }}
		{%- endif -%}



{{ shop.metafields.judgeme.settings | replace: 'type="text/javascript" async src="', 'type="lazyload2" data-src="' | replace: 'type="text/css" media="nope!" onload="this.media=', '' | replace: "'all'", '' | replace: '" href=', 'data-href='  }}


    {% if template contains 'index' or template contains 'collection' or template contains 'page' or template contains 'search' %}
	{% render "font-css" %}
    {% endif %}
	
	
	
	
{% if template contains 'collection' or template contains 'search' %}
<!-- Include Resources -->
<script defer src="{{ 'bc-sf-filter-lib.js' | asset_url }}"></script>
<script defer src="{{ 'boost-pfs-multiple-currencies.js' | asset_url }}"></script>
<script defer src="{{ 'bc-sf-search.js' | asset_url }}"></script>
{%- if bcsffilter_is_initfilter == true -%}
  <script defer src="{{ 'bc-sf-filter.js' | asset_url }}"></script>
{%- endif -%}

<!-- Initialize App -->
<script defer src="{{ 'bc-sf-filter-init.js' | asset_url }}"></script>
<script defer src="{{ 'bc-sf-filter-analytics.js' | asset_url }}"></script>
{% else %}
<!-- Include Resources -->
<script type="lazyload2" data-src="{{ 'bc-sf-filter-lib.js' | asset_url }}"></script>
<script type="lazyload2" data-src="{{ 'boost-pfs-multiple-currencies.js' | asset_url }}"></script>
<script type="lazyload2" data-src="{{ 'bc-sf-search.js' | asset_url }}"></script>
{%- if bcsffilter_is_initfilter == true -%}
  <script type="lazyload2" data-src="{{ 'bc-sf-filter.js' | asset_url }}"></script>
{%- endif -%}

<!-- Initialize App -->
<script type="lazyload2" data-src="{{ 'bc-sf-filter-init.js' | asset_url }}"></script>
<script type="lazyload2" data-src="{{ 'bc-sf-filter-analytics.js' | asset_url }}"></script>
{% endif %}



{% capture gem-app-footer-scripts %}
    {% include 'gem-app-footer-scripts' %}
{% endcapture %}    
{{ gem-app-footer-scripts | replace: '<script data-instant-track type="text/javascript" src="', '<script data-instant-track type="lazyload2" data-src="'}}




    {%- if request.design_mode or template contains 'cart' or template contains 'checkout' -%}
    	{{ content_for_header }}
    {%- else -%}
    	{% capture content_for_header2 %}{{ content_for_header }}{% endcapture %}
    	{{ content_for_header2 | replace: ' defer="defer" ', ' type="lazyload2" ' | replace: " src=", " data-src=" | replace: "window.addEventListener('load', asyncLoad, false);", "window.addEventListener('wnw_load', asyncLoad, false);" | replace: "DOMContentLoaded", "DOMContentLoaded2" | replace: "addEventListener('load', prefetchAssets);", "addEventListener('wnw_load', prefetchAssets);" }}
    	<script>var trekkie=[];trekkie.integrations=!0;window.BOOMR={},window.BOOMR.version=true;</script>
    {%- endif -%}
	
	
	
	.hero > .slideshow__slide:nth-child(1)  > .hero__image-wrapper {
    transform: scale(1) !important;
    opacity:1 !important;
}



{%- if img_type == 'responsive' -%}
    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-class="LazyLoad"
    {%- assign img_url = img | img_url: '1x1', crop: crop | replace: '_1x1', '_{width}x{height}' -%}
    data-srcset="{{ img | img_url: '1512x', crop: crop }} 1536w,{{ img | img_url: '1080x', crop: crop }} 1280w,{{ img | img_url: '720x', crop: crop }} 768w,{{ img | img_url: '540x', crop: crop }} 320w"
    data-sizes="auto"
    data-widths="[180, 360, 540, 720, 900, 1080, 1296, 1512, 1728, 2048]"
    {%- if crop -%}
    data-aspectratio="1.0"
    {%- else -%}
    data-aspectratio="{{ img.aspect_ratio | default: img.preview_image.aspect_ratio }}"
    {%- endif -%}
{%- elsif img_type == 'retina' -%}
    {%- if img_width -%}
    width="{{ img_width }}"
    {%- endif -%}
    {%- if img_height -%}
    height="{{ img_height }}"
    {%- endif -%}
    {%- capture img_size %}{{ img_width }}x{{ img_height }}{%- endcapture -%}
    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-class="LazyLoad"
    data-src="{{ img | img_url: img_size, crop: crop }}"
    data-srcset="{{ img | img_url: img_size, crop: crop }} 1x, {{ img | img_url: img_size, scale: 2, crop: crop }} 2x" 
{%- elsif img_type == 'svg' -%}
    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-class="LazyLoad"
    data-src="{{ img | asset_url }}"
    {%- if img_width -%}
    width="{{ img_width }}"
    {%- endif -%}
    {%- if img_height -%}
    height="{{ img_height }}"
    {%- endif -%}
{%- elsif img_type == 'background' -%}
    {%- capture bgset -%}
        {%- if img_mobile != blank -%}
            {%- if img_mobile.width > 180 -%}{{ img_mobile | img_url: '180x' }} 180w {{ 180 | divided_by: img_mobile.aspect_ratio | round }}h,{%- endif -%}
            {%- if img_mobile.width > 360 -%}{{ img_mobile | img_url: '360x' }} 360w {{ 360 | divided_by: img_mobile.aspect_ratio | round }}h,{%- endif -%}
            {%- if img_mobile.width > 540 -%}{{ img_mobile | img_url: '540x' }} 540w {{ 540 | divided_by: img_mobile.aspect_ratio | round }}h,{%- endif -%}
            {%- if img_mobile.width > 720 -%}{{ img_mobile | img_url: '720x' }} 720w {{ 720 | divided_by: img_mobile.aspect_ratio | round }}h,{%- endif -%}
            {%- if img_mobile.width > 900 -%}{{ img_mobile | img_url: '900x' }} 900w {{ 900 | divided_by: img_mobile.aspect_ratio | round }}h,{%- endif -%}
            {%- if img_mobile.width > 1080 -%}{{ img_mobile | img_url: '1080x' }} 1080w {{ 1080 | divided_by: img_mobile.aspect_ratio | round }}h,{%- endif -%}
            {{- ' [--small] | ' -}}
        {%- endif -%}

        {%- if img.width > 180 -%}{{ img | img_url: '180x' }} 180w {{ 180 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 360 -%}{{ img | img_url: '360x' }} 360w {{ 360 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 540 -%}{{ img | img_url: '540x' }} 540w {{ 540 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 720 -%}{{ img | img_url: '720x' }} 720w {{ 720 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 900 -%}{{ img | img_url: '900x' }} 900w {{ 900 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 1080 -%}{{ img | img_url: '1080x' }} 1080w {{ 1080 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 1296 -%}{{ img | img_url: '1296x' }} 1296w {{ 1296 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 1512 -%}{{ img | img_url: '1512x' }} 1512w {{ 1512 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 1728 -%}{{ img | img_url: '1728x' }} 1728w {{ 1728 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {{ img | img_url: 'master' }} {{ img.width }}w {{ img.height }}h
    {%- endcapture -%}
    {% comment %}
    data-bgset="{{ bgset }}"
    {% endcomment %}
    style="background-image:url({{ img | img_url: '1512x' }})"
    data-sizes="auto"
    data-parent-fit="cover"
{%- endif -%}

{%- if img_type == 'responsive' -%}
    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-class="LazyLoad"
    {%- assign img_url = img | img_url: '1x1', crop: crop | replace: '_1x1', '_{width}x{height}' -%}
    data-srcset="{{ img | img_url: '1512x', crop: crop }} 1536w,{{ img | img_url: '1080x', crop: crop }} 1280w,{{ img | img_url: '720x', crop: crop }} 768w,{{ img | img_url: '540x', crop: crop }} 320w"
    data-sizes="auto"
    data-widths="[180, 360, 540, 720, 900, 1080, 1296, 1512, 1728, 2048]"
    {%- if crop -%}
    data-aspectratio="1.0"
    {%- else -%}
    data-aspectratio="{{ img.aspect_ratio | default: img.preview_image.aspect_ratio }}"
    {%- endif -%}
{%- elsif img_type == 'retina' -%}
    {%- if img_width -%}
    width="{{ img_width }}"
    {%- endif -%}
    {%- if img_height -%}
    height="{{ img_height }}"
    {%- endif -%}
    {%- capture img_size %}{{ img_width }}x{{ img_height }}{%- endcapture -%}
    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-class="LazyLoad"
    data-src="{{ img | img_url: img_size, crop: crop }}"
    data-srcset="{{ img | img_url: img_size, crop: crop }} 1x, {{ img | img_url: img_size, scale: 2, crop: crop }} 2x" 
{%- elsif img_type == 'svg' -%}
    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-class="LazyLoad"
    data-src="{{ img | asset_url }}"
    {%- if img_width -%}
    width="{{ img_width }}"
    {%- endif -%}
    {%- if img_height -%}
    height="{{ img_height }}"
    {%- endif -%}
{%- elsif img_type == 'background' -%}
    {%- capture bgset -%}
        {%- if img_mobile != blank -%}
            {%- if img_mobile.width > 180 -%}{{ img_mobile | img_url: '180x' }} 180w {{ 180 | divided_by: img_mobile.aspect_ratio | round }}h,{%- endif -%}
            {%- if img_mobile.width > 360 -%}{{ img_mobile | img_url: '360x' }} 360w {{ 360 | divided_by: img_mobile.aspect_ratio | round }}h,{%- endif -%}
            {%- if img_mobile.width > 540 -%}{{ img_mobile | img_url: '540x' }} 540w {{ 540 | divided_by: img_mobile.aspect_ratio | round }}h,{%- endif -%}
            {%- if img_mobile.width > 720 -%}{{ img_mobile | img_url: '720x' }} 720w {{ 720 | divided_by: img_mobile.aspect_ratio | round }}h,{%- endif -%}
            {%- if img_mobile.width > 900 -%}{{ img_mobile | img_url: '900x' }} 900w {{ 900 | divided_by: img_mobile.aspect_ratio | round }}h,{%- endif -%}
            {%- if img_mobile.width > 1080 -%}{{ img_mobile | img_url: '1080x' }} 1080w {{ 1080 | divided_by: img_mobile.aspect_ratio | round }}h,{%- endif -%}
            {{- ' [--small] | ' -}}
        {%- endif -%}

        {%- if img.width > 180 -%}{{ img | img_url: '180x' }} 180w {{ 180 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 360 -%}{{ img | img_url: '360x' }} 360w {{ 360 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 540 -%}{{ img | img_url: '540x' }} 540w {{ 540 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 720 -%}{{ img | img_url: '720x' }} 720w {{ 720 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 900 -%}{{ img | img_url: '900x' }} 900w {{ 900 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 1080 -%}{{ img | img_url: '1080x' }} 1080w {{ 1080 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 1296 -%}{{ img | img_url: '1296x' }} 1296w {{ 1296 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 1512 -%}{{ img | img_url: '1512x' }} 1512w {{ 1512 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {%- if img.width > 1728 -%}{{ img | img_url: '1728x' }} 1728w {{ 1728 | divided_by: img.aspect_ratio | round }}h,{%- endif -%}
        {{ img | img_url: 'master' }} {{ img.width }}w {{ img.height }}h
    {%- endcapture -%}
    {% comment %}
    data-bgset="{{ bgset }}"
    {% endcomment %}
    {% if img_mobile != blank %}
        style="background-image:url({{ img_mobile | img_url: '540x' }})"
    {% else %}
        style="background-image:url({{ img | img_url: '540x' }})"
    {% endif %}
    data-sizes="auto"
    data-parent-fit="cover"
{%- endif -%}


data-class="LazyLoad"



<script>
            jQuery(".gallery-thumbs-outer").each(function() {
            	if ( jQuery(this).data('media-count') == 2) {
            		jQuery(this).find(".swiper-slide").css("width", "43.3%");
            	}
              if ( jQuery(this).data('media-count') == 3) {
            		jQuery(this).find(".swiper-slide").css("width", "28.1%");
            	}
              if ( jQuery(this).data('media-count') == 4) {
            		jQuery(this).find(".swiper-slide").css("width", "20.6%");
            	}
            })
        </script>   
		
		
		{{ shop.metafields.judgeme.settings | replace: '<script data-cfasync="false" type="text/javascript" async src="', '<script data-cfasync="false" type="lazyload2" data-src="' | replace: 'type="text/css" media="nope!" onload="this.media=', '' | replace: "'all'", "" | replace: '" href="', 'data-href="' }}


Startup - Backup 05.10.2017


function lazyloadiframes(top) {
        var bodyRect = document.body.getBoundingClientRect();
        var window_height = window.innerHeight;
        var win_width = screen.availWidth;
        var iframes = document.querySelectorAll("iframelazy[data-class=LazyLoad]");
        lazyload_img(iframes, bodyRect, window_height, win_width);
        setTimeout(function() {
            console.log("2254");
            if(window.site_nav_link_burger == false) {
                console.log("2255");
                jQuery(".openmenu").click();
                window.site_nav_link_burger = false;
            }
        });
    }
	
	
	saurabh.roy@webnware.in
	Shawn$@123
	Resetyourpassword@123
	https://media.tenor.com/EibiAn5b9ZsAAAAC/throw-him-out-bahar-fek-do-issey.gif
	
	3050086
	
	
	       src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
           data-src="{{ img_url }}"
           data-srcset="{{ card_collection.featured_image | img_url: '1024x' }} 1536w,{{ card_collection.featured_image | img_url: '480x' }} 1280w,{{ card_collection.featured_image | img_url: '360x' }} 768w,{{ card_collection.featured_image | img_url: '280x'}} 320w"
           data-class="LazyLoad"
		   
		   
		   
		   
		   
<link rel="preload" href="" as="font" type="font/woff2" crossorigin>

<body class="{{ template.name }}">

(function ($) {
    var $body = $('body'),
        $doc = $(document),
        $html = $('html'),
        $win = $(window);

setTimeout(function() {
        $doc.ajaxStart(() => {
            halo.isAjaxLoading = true;
        });

        $doc.ajaxStop(() => {
            halo.isAjaxLoading = false;
        });

        halo.ready();
    });

setTimeout(function() {
        halo.init();
    });
	
	[data-value="foo"]
	
	{%- if request.design_mode or template contains 'cart' or template contains 'checkout' -%}
            {{ content_for_header }}
    {%- else -%}
            {% capture content_for_header2 %}{{ content_for_header }}{% endcapture %}
            {{ content_for_header2 | replace: ' defer="defer" ', ' type="lazyload_int" ' | replace: " src=", " data-src="| replace: "DOMContentLoaded", "w3-DOMContentLoaded" | replace: "window.addEventListener('load', asyncLoad, false);", "window.addEventListener('w3-DOMContentLoaded', asyncLoad, false);" | replace: "addEventListener('load', prefetchAssets);", "addEventListener('w3-DOMContentLoaded', prefetchAssets);" }}
            <script>var trekkie=[];trekkie.integrations=!0;window.BOOMR={},window.BOOMR.version=true;</script>
    {%- endif -%}
	
	
{% if product %}
    <script data-ver="13" id="vtls-product-data">
        var vitals_product_data={"id": {{ product.id | json }}, "available": {{ product.available | json }}, "title": {{ product.title | json }}, "handle": {{ product.handle | json }}, "vendor": {{ product.vendor | json }}, "type": {{ product.type | json }}, "tags": {{ product.tags | json }}, "description": "{% unless product.description == blank %}1{% endunless %}", "featured_image": {% if product.featured_image %}{"src": "{{ product.featured_image | img_url: 'master' }}","aspect_ratio": "{{ product.featured_image.aspect_ratio }}"}{% else %}null{% endif %}, "collectionIds": [{% for c in product.collections %}{{c.id}}, {% endfor %}], "variants": [{% for v in product.variants %}{"id": {{ v.id | json }}, "title": {{ v.title | json }}, "option1": {{ v.option1 | json }}, "option2": {{ v.option2 | json }}, "option3": {{ v.option3 | json }}, "price": {{ v.price | json }}, "compare_at_price": {{ v.compare_at_price | json }}, "available": {{ v.available | json }}, "image": {% if v.image %}{"src": "{{ v.image | img_url: 'master' }}","alt": {{ v.image.alt | json }},"aspect_ratio": {{ v.image.aspect_ratio | json }}}{% else %}null{% endif %}, "is_preorderable": {% if v.inventory_management and v.inventory_quantity <= 0 and v.inventory_policy == 'continue' %}1{% else %}0{% endif %}, "inventory_quantity": {{ v.inventory_quantity | json }}, },{% endfor %}]};
        {% if product.metafields.vitals.vitalsDok != blank %}var vitals_upsell_builder_cache_key = '{{ product.metafields.vitals.vitalsDok }}';{% endif %}
    </script>
{% endif %}
{{ shop.metafields.vitals["setupScript"] }}
<script src="https://appsolve.io/sf/v1/assets/js/main/magalis-egypt.myshopify.com/1689971594/bundle.js" async></script>



    {% if template contains "product" %}
      <!-- BEGIN app block: shopify://apps/vitals-all-in-one-marketing/blocks/app-embed/aeb48102-2a5a-4f39-bdbd-d8d49f4e20b8 -->
      <script data-ver="13" id="vtlsAebData">window.vtlsLiquidData = {};window.vtlsLiquidData.product = {"id": 8146243420426,"available": true,"title": "Pollen de pin","handle": "pollen-de-pin","vendor": "Polenn","type": "","tags": ["Gelule"],"description": "1","featured_image":{"src": "//polenn.co/cdn/shop/products/Polenn_Anti-fatigue.png?v=1683801576","aspect_ratio": "1.0"},"collectionIds": [489930817802,],"variants": [{"id": 44344087740682,"title": "Poudre \/ 1 mois","option1": "Poudre","option2": "1 mois","option3": null,"price": 4590,"compare_at_price": null,"available": true,"image":{"src": "//polenn.co/cdn/shop/products/Polenn-Produit-economie.png?v=1687955117","alt": "Pollen de pin","aspect_ratio": 1.049636803874092},"is_preorderable": 0},{"id": 44344087773450,"title": "Poudre \/ 2 mois","option1": "Poudre","option2": "2 mois","option3": null,"price": 7690,"compare_at_price": null,"available": true,"image":{"src": "//polenn.co/cdn/shop/products/Polenn-utilisation.png?v=1686253289","alt": "Pollen de pin","aspect_ratio": 1.0},"is_preorderable": 0},{"id": 44315339030794,"title": "Gélule \/ 1 mois","option1": "Gélule","option2": "1 mois","option3": null,"price": 5290,"compare_at_price": null,"available": true,"image":{"src": "//polenn.co/cdn/shop/products/Polenn-gelule.png?v=1686253289","alt": "Pollen de pin","aspect_ratio": 1.0},"is_preorderable": 0},{"id": 44315339063562,"title": "Gélule \/ 2 mois","option1": "Gélule","option2": "2 mois","option3": null,"price": 9290,"compare_at_price": null,"available": true,"image":{"src": "//polenn.co/cdn/shop/products/Polenn-gelule.png?v=1686253289","alt": "Pollen de pin","aspect_ratio": 1.0},"is_preorderable": 0},{"id": 44593634607370,"title": "Comprimé \/ 1 mois","option1": "Comprimé","option2": "1 mois","option3": null,"price": 5490,"compare_at_price": null,"available": true,"image":{"src": "//polenn.co/cdn/shop/files/Polenn-comprime.jpg?v=1686253289","alt": "Pollen de pin","aspect_ratio": 1.000292997363024},"is_preorderable": 0},{"id": 44593634640138,"title": "Comprimé \/ 2 mois","option1": "Comprimé","option2": "2 mois","option3": null,"price": 9490,"compare_at_price": null,"available": true,"image":{"src": "//polenn.co/cdn/shop/files/Polenn-comprime.jpg?v=1686253289","alt": "Pollen de pin","aspect_ratio": 1.000292997363024},"is_preorderable": 0},],"options": [{"name": "Forme"},{"name": "Cure"},]};window.vtlsLiquidData.cacheKeys = [1687564878,1690719465,1690888105,1690719465,1687564878,0,0];</script>
      <script data-src="https://appsolve.io/sf/v1/assets/js/main/polenn-3935.myshopify.com/1691052121/bundle.js" type="lazyload_int"></script>
      <!-- END app app block -->
    {% else %}
      <!-- BEGIN app block: shopify://apps/vitals-all-in-one-marketing/blocks/app-embed/aeb48102-2a5a-4f39-bdbd-d8d49f4e20b8 -->
      <script data-ver="13" id="vtlsAebData">window.vtlsLiquidData = {};window.vtlsLiquidData.cacheKeys = [1687564878,1690719465,1690888105,1690719465,1687564878,0,0];</script>
      <script data-src="https://appsolve.io/sf/v1/assets/js/main/polenn-3935.myshopify.com/1691052121/bundle.js" type="lazyload_int"></script>
      <!-- END app app block -->
    {% endif %}


    {%- if request.design_mode or template contains 'cart' or template contains 'checkout' -%}
            {{ content_for_header }}
    {%- else -%}
            {% capture content_for_header2 %}{{ content_for_header }}{% endcapture %}
            {{ content_for_header2 | replace: ' defer="defer" ', ' type="lazyload_int" ' | replace: " src=", " data-src="| replace: "DOMContentLoaded", "w3-DOMContentLoaded" | replace: "window.addEventListener('load', asyncLoad, false);", "window.addEventListener('w3-DOMContentLoaded', asyncLoad, false);" | replace: "addEventListener('load', prefetchAssets);", "addEventListener('w3-DOMContentLoaded', prefetchAssets);" }}
            <script>var trekkie=[];trekkie.integrations=!0;window.BOOMR={},window.BOOMR.version=true;</script>
    {%- endif -%}