<?php
namespace W3speedster;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class w3speedster_js extends w3speedster_css{

    
	function w3_modify_file_cache_js($html, $path){
		$src_array = explode('/',$path);
		$count = count($src_array);
		unset($src_array[$count-1]);
		if(!empty($this->settings[base64_decode('aXNfYWN0aXZhdGVk')]) && !empty($this->settings['load_combined_js'])){
			if((strpos($html,'holdready:') !== false || strpos($html,'S.holdReady') !== false) && empty($this->add_settings['holdready'])){
				$html .= ';if(typeof($) == "undefined"){$ = jQuery;}else{var $ = jQuery;}';
				$this->add_settings['holdready'] = 1;
			}
			$exclude_from_w3_changes = 0;
			if(function_exists('w3speedup_exclude_internal_js_w3_changes')){
				$exclude_from_w3_changes = w3speedup_exclude_internal_js_w3_changes($path,$html);
			}
			if(strpos($html,'holdready:') === false && !$exclude_from_w3_changes){
				
				$html = $this->w3_changes_in_js($html);
				
			}
		}
		if(function_exists('w3speedup_internal_js_customize')){
			$html = w3speedup_internal_js_customize($html,$path);
		}
		return $html;
	}
	function w3_create_file_cache_js_url($path){
	    $cache_file_path = $this->w3_get_cache_path('js').'/'.md5($this->add_settings['w3_rand_key'].$path).'.js';
        if( !file_exists($cache_file_path) ){
            //$this->w3_check_if_folder_exists($this->w3_get_cache_path('js'));
			$html = file_get_contents($path);
            $html = $this->w3_modify_file_cache_js($html, $path);
            $this->w3_create_file($cache_file_path, $html );
        }
	    return str_replace($this->add_settings['document_root'],'',$cache_file_path);
    }
	function w3_changes_in_js($html){
		$html = preg_replace('/"(\s*)use strict(\s*)"(\s*);/', '', $html, 1);
		$html = preg_replace('/([\s\;\:\}\,\)\(\{])([a-zA-Z]+)([.]addEventListener\s*\(\s*[\'|"]\s*readystatechange\s*[\'|"]\s*,)/', "$1$2.addEventListener('w3-DOMContentLoaded',", $html);
		$html = preg_replace('/([\s\;\:\}\,\)\(\{])([a-zA-Z]+)([.]addEventListener\s*\(\s*[\'|"]\s*DOMContentLoaded\s*[\'|"]\s*,)/', "$1$2.addEventListener('w3-DOMContentLoaded',", $html);
		$html = preg_replace('/(jQuery|\$)(\s*\(\s*)(\(*\s*)(\s*function\s*\(\s*[\S|\$]*\s*\))/', 'jQuery(document).ready($3$4', $html);
		$html = preg_replace('/(jQuery|\$)(\s*\(\s*)([\(\s]*\(\s*\(\s*\)=>)/', 'jQuery(document).ready($3', $html);
		$html = preg_replace('/(jQuery|\$)(\s*\(\s*)(document)(\)\s*)\.on(\s*\([\'|\"]\s*ready\s*[\'|\"]\s*),(\s*function\s*\(\s*[.]*\s*\))/', "jQuery(document).ready($6", $html);
		
		return $html;
	}
    function w3_create_file_cache_js($path){
	    $cache_file_path = $this->w3_get_cache_path('js').'/'.md5($this->add_settings['w3_rand_key'].$path).'.js';
        if( !file_exists($cache_file_path) ){
            $html = file_get_contents($this->add_settings['document_root'].$path);
            $html = $this->w3_modify_file_cache_js($html, $path);
            $this->w3_create_file($cache_file_path, $html );
        }
	    return str_replace($this->add_settings['document_root'],'',$cache_file_path);
    }
    
    function w3_compress_js($html){
        include_once W3SPEEDSTER_PLUGIN_DIR.'includes/jsmin.php';
        $html = \W3jsMin::minify($html);
        return $html;
    }
    function minify_css($html,$all_links){
       return parent::minify_css($html,$all_links);
    }
	
    function minify($html, $script_links){
        if(!empty($this->settings['exclude_page_from_load_combined_js']) && $this->w3_check_if_page_excluded($this->settings['exclude_page_from_load_combined_js'])){
			return $html;
        }
		if(!empty($script_links) && !empty($this->settings['js'])){
			$lazy_load_js = !empty($this->settings['load_combined_js']) && $this->settings['load_combined_js'] == 'after_page_load' ? 1 : 0;
			$force_innerjs_to_lazy_load  = !empty($this->settings['force_lazy_load_inner_javascript']) ? explode("\r\n", $this->settings['force_lazy_load_inner_javascript']) : array();
            $exclude_js_arr_split  = !empty($this->settings['exclude_javascript']) ? explode("\r\n", $this->settings['exclude_javascript']) : array();
			foreach($exclude_js_arr_split as $key => $value){
				if(strpos($value,' defer') !== false){
					$exclude_js_arr[$key]['string'] = str_replace(' defer','',$value);
					$exclude_js_arr[$key]['defer'] = 1;
				}elseif(strpos($value,' full') !== false){
					$exclude_js_arr[$key]['string'] = str_replace(' full','',$value);
					$exclude_js_arr[$key]['full'] = 1;
				}else{	
					$exclude_js_arr[$key]['string'] = $value;
					$exclude_js_arr[$key]['defer'] = 0;
				}
			}
            $exclude_inner_js= !empty($this->settings['exclude_inner_javascript']) ? explode("\r\n", stripslashes($this->settings['exclude_inner_javascript'])) : array('google-analytics', 'hbspt',base64_decode("LyogPCFbQ0RBVEFbICov"));
            $load_ext_js_before_internal_js = !empty($this->settings['load_external_before_internal']) ? explode("\r\n", $this->settings['load_external_before_internal']) : array();
            $all_js='';
            $included_js = array();
            $final_merge_js = array();
            $js_file_name = '';
            $enable_cdn = 0;
            if($this->add_settings['image_home_url'] != $this->add_settings['wp_site_url']){
				$ext = '.js';
				if(empty($this->add_settings['exclude_cdn']) || !in_array($ext,$this->add_settings['exclude_cdn'])){
					$enable_cdn = 1;
				}
			}
			
			$final_merge_has_js = array();
			for($si=0; $si < count($script_links); $si++){
                $script = $script_links[$si];
				$script_obj = !empty($this->add_settings['script_obj'][$si]) ? $this->add_settings['script_obj'][$si] : $this->w3_parse_link('script',str_replace($this->add_settings['image_home_url'],$this->add_settings['wp_site_url'],$script_links[$si]));
				$script_text = '';
				if(!array_key_exists('src',$script_obj)){
                    $script_text = $this->w3_parse_script('<script',$script);
                }
				if(!empty($script_obj['type']) && strtolower($script_obj['type']) != 'application/javascript' && strtolower($script_obj['type']) != 'module' && strtolower($script_obj['type']) != 'text/javascript' && strtolower($script_obj['type']) != 'text/jsx;harmony=true'){
                    continue;
                }
				if(function_exists('w3speedup_customize_script_object')){
					$script_obj = w3speedup_customize_script_object($script_obj, $script);
				}
                if(!empty($script_obj['src'])){
					
					//echo $script_obj['src'];
                    $url_array = $this->w3_parse_url($script_obj['src']);
                    $exclude_js = 0;
                    if(!empty($exclude_js_arr) && is_array($exclude_js_arr)){
						foreach($exclude_js_arr as $ex_js){
							if(strpos($script,$ex_js['string']) !== false){
								if(!empty($ex_js['defer'])){
									$exclude_js = 2;
								}elseif(!empty($ex_js['full'])){
									$exclude_js = 3;
								}else{
									$exclude_js = 1;
								}
							}
						}
					}
					if(function_exists('w3speedup_exclude_javascript_filter')){
						$exclude_js = w3speedup_exclude_javascript_filter($exclude_js,$script_obj,$script,$html);
					}
					if(!$this->w3_is_external($script_obj['src']) && $this->w3_endswith($url_array['path'], '.js') && $exclude_js != 3){
                        $old_path = $url_array['path'];
                        if(file_exists($this->add_settings['document_root'].$url_array['path'])){
							$url_array['path'] = $this->w3_create_file_cache_js($url_array['path']);
						}else{
							$url_array['path'] = $this->w3_create_file_cache_js_url($script_obj['src']);
						}
                        $script_obj['src'] = $this->add_settings['wp_site_url'].$url_array['path'];
                    }
                    if($exclude_js){
                        if( $exclude_js == 3){
							$script_obj['src'] = $enable_cdn ? str_replace($this->add_settings['wp_site_url'],$this->add_settings['image_home_url'] ,$script_obj['src']) : $script_obj['src'];
							$this->add_settings['preload_resources'][] = $script_obj['src'];
							$this->w3_str_replace_set($script,$this->w3_implode_link_array('script',$script_obj));
							continue;
						}
						if( $exclude_js == 2){
                            $script_obj['defer'] = 'defer';
						}
						if(file_exists($this->add_settings['document_root'].$url_array['path']) && strpos(file_get_contents($this->add_settings['document_root'].$url_array['path']),'jQuery requires a window with a document') !== false){
							$this->add_settings['jquery_excluded'] = $this->add_settings['document_root'].$url_array['path'];
						}
						$script_obj['src'] = $enable_cdn ? str_replace($this->add_settings['wp_site_url'],$this->add_settings['image_home_url'] ,$script_obj['src']) : $script_obj['src'];
						if(!empty($exclude_js) && $exclude_js == 1){
							$this->add_settings['preload_resources'][] = $script_obj['src'];
						}
						$this->w3_str_replace_set($script,$this->w3_implode_link_array('script',$script_obj));
                        continue;
                    }
                    $exclude_js_bool=0;
					if(!empty($force_innerjs_to_lazy_load)){
                        foreach($force_innerjs_to_lazy_load as $js){
                            if( !empty($js) && strpos($script,$js) !== false){
                                $exclude_js_bool=1;
                                break;
                            }
                        }
                    }
					
                    $val = $script_obj['src'];
                    if(!empty($val) && !$this->w3_is_external($val) && strpos($script, '.js') && empty($exclude_js_bool)){
                        $final_merge_js[] = $url_array['path'];
						$final_merge_has_js[] = $script;
						if(!empty($final_merge_js) && count($final_merge_js) > 0){
							$cache_js_url = $this->w3_create_js_combined_cache_file($final_merge_js, $enable_cdn);
							$this->w3_replace_js_files_with_combined_files($final_merge_has_js,$cache_js_url);
							$final_merge_js = array();
							$final_merge_has_js = array();
						}
					}elseif($this->w3_is_external($val) && empty($exclude_js_bool) ){
						$script_obj['type'] = 'lazyload_int';
						$script_obj['data-src'] = $script_obj['src'];
						unset($script_obj['src']);
						$this->w3_str_replace_set($script,$this->w3_implode_link_array('script',$script_obj));
					}elseif($exclude_js_bool){
						$script_obj['data-src'] = $enable_cdn ? str_replace($this->add_settings['wp_site_url'],$this->add_settings['image_home_url'] ,$script_obj['src']) : $script_obj['src'];
						unset($script_obj['src']);
						$script_obj['type'] = 'lazyload_ext';
						if(function_exists('w3_external_javascript_customize')){
							$script_obj = w3_external_javascript_customize($script_obj, $script);
						}
						$this->w3_str_replace_set($script,$this->w3_implode_link_array('script',$script_obj));
                    }
                }else{
                    
                    $inner_js = $script_text;
                    $lazy_loadjs = 0;
                    $exclude_js_bool = 0;
					$force_js_bool = 0;
                    $exclude_js_bool = $this->w3_check_js_if_excluded($inner_js, $exclude_inner_js);
					if(function_exists('w3speedup_inner_js_customize')){
						$script_text = w3speedup_inner_js_customize($script_text);
					}
					if(!empty($force_innerjs_to_lazy_load)){
                        foreach($force_innerjs_to_lazy_load as $js){
                            if(strpos($script_text,$js) !== false){
                                $exclude_js_bool=0;
								$force_js_bool = 1;
                                break;
                            }
                        }
                    }
                    if(!empty($exclude_js_bool) && $exclude_js_bool != 2){
						if(function_exists('w3speedup_inner_js_customize')){
							$this->w3_str_replace_set($script,'<script>'.$script_text.'</script>');
						}
					}else{
						if($exclude_js_bool == 2){
							$script_modified = '<script type="lazyload_int" ';
						}elseif($force_js_bool){
    						$script_modified = '<script type="lazyload_ext" ';
    					}else{
    						$script_modified = '<script type="lazyload_int" ';
    					}
    					foreach($script_obj as $key => $value){
                            if($key != 'type' && $key != 'html'){
                                $script_modified .= $key.'="'.$value.'" ';
                            }
                        }
						if(!empty($this->settings[base64_decode('aXNfYWN0aXZhdGVk')]) && !empty($this->settings['load_combined_js']) && $this->settings['load_combined_js'] == 'after_page_load' && !empty($force_js_bool)){
							$script_text = $this->w3_changes_in_js($script_text);
						}
						
						if(!empty($this->settings['minify_html'])){
							$script_modified = $script_modified.'>'.$this->w3_compress_js($script_text).'</script>';
                        }else{
							$script_modified = $script_modified.'>'.$script_text.'</script>';
						}
						$this->w3_str_replace_set($script,$script_modified);
						if(!empty($final_merge_js) && count($final_merge_js) > 0){
							$cache_js_url = $this->w3_create_js_combined_cache_file($final_merge_js, $enable_cdn);
							$this->w3_replace_js_files_with_combined_files($final_merge_has_js,$cache_js_url);
							$final_merge_js = array();
							$final_merge_has_js = array();
						}
						
					}
                }
				if($si == count($script_links)-1 && !empty($final_merge_has_js)){
					if(!empty($final_merge_js) && count($final_merge_js) > 0){
						$cache_js_url = $this->w3_create_js_combined_cache_file($final_merge_js, $enable_cdn);
						$this->w3_replace_js_files_with_combined_files($final_merge_has_js, $cache_js_url);
						$final_merge_js = array();
					}
				}
            }
			if(!empty($this->settings['custom_javascript'])){
			   if(!empty($this->settings['custom_javascript_file'])){    
					$custom_js_path = $this->w3_get_cache_path('all-js').'/wnw-custom-js.js';
					if(!is_file($custom_js_path)){
						$this->w3_create_file($custom_js_path, stripslashes($this->settings['custom_javascript']));
					}
					$custom_js_url = $this->w3_get_cache_url('all-js').'/wnw-custom-js.js';
					$custom_js_url = $enable_cdn ? str_replace($this->add_settings['wp_site_url'],$this->add_settings['image_home_url'] ,$custom_js_url) : $custom_js_url;
					$position = strrpos($html,'</body>');
					$html = substr_replace( $html, '<script '.(!empty($this->settings['custom_javascript_defer']) ? 'defer="defer"' : '').' id="wnw-custom-js" src="'.$custom_js_url.'?ver='.rand(10,1000).'"></script>', $position, 0 );
				}else{
					$position = strrpos($html,'</body>');
					$html = substr_replace( $html, '<script>'.stripslashes($this->settings['custom_javascript']).'</script>', $position, 0 ); 
				}
			}
		}
        
        
        return $html;
    }
	function w3_check_js_if_excluded($inner_js, $exclude_inner_js){
		$exclude_js_bool=0;
		if(strpos($inner_js,'moment.') === false && strpos($inner_js,'wp.') === false && strpos($inner_js,'.noConflict') === false && strpos($inner_js,'wp.i18n') === false){
			$exclude_js_bool=2;
		}
		if(strpos($inner_js,'DOMContentLoaded') !== false || strpos($inner_js,'jQuery(') !== false || strpos($inner_js,'$(') !== false || strpos($inner_js,'jQuery.') !== false || strpos($inner_js,'$.') !== false){
			$exclude_js_bool=2;
		}
		
		if(!empty($exclude_inner_js)){
			foreach($exclude_inner_js as $js){
				if(strpos($inner_js,$js) !== false){
					return 1;
					break;
				}
			}
		}
		return $exclude_js_bool;
	}
	function w3_replace_js_files_with_combined_files($final_merge_has_js,$cache_js_url){
		if(!empty($final_merge_has_js)){
			$lazy_load_js = !empty($this->settings['load_combined_js']) && $this->settings['load_combined_js'] == 'after_page_load' ? 1 : 0;
			for($ii = 0; $ii < count($final_merge_has_js); $ii++){
				if($ii == count($final_merge_has_js) -1 ){
					$this->w3_str_replace_set($final_merge_has_js[$ii],'<script type="lazyload_int" data-src="'.$cache_js_url.'"></script>');
				}else{
					$this->w3_str_replace_set($final_merge_has_js[$ii],'');
				}
			}
		}
	}
	
	function w3_create_js_combined_cache_file($final_merge_js, $enable_cdn){
		$file_name = is_array($final_merge_js) ? $this->add_settings['w3_rand_key'].'-'.implode('-', $final_merge_js) : '';
		if(!empty($file_name)){
			$js_file_name = md5($file_name).$this->add_settings['js_ext'];
			if(!is_file($this->w3_get_cache_path('all-js').'/'.$js_file_name)){
				$all_js = '';
				foreach($final_merge_js as $key => $script_path){
					$all_js .= file_get_contents($this->add_settings['document_root'].$script_path).";\n";
				}
				$this->w3_create_file($this->w3_get_cache_path('all-js').'/'.$js_file_name, $all_js);
			}
			$main_js_url = $this->w3_get_cache_url('all-js').'/'.$js_file_name;
			$main_js_url = $enable_cdn ? str_replace($this->add_settings['wp_site_url'],$this->add_settings['image_home_url'] ,$main_js_url) : $main_js_url;
			return $main_js_url;
		}
	}
    function w3_lazy_load_javascript(){
		$enable_cdn = 0;
		if($this->add_settings['image_home_url'] != $this->add_settings['wp_site_url'] ){
			$enable_cdn = 1;
		}
		$exclude_cdn_arr = !empty($this->add_settings['exclude_cdn']) ? $this->add_settings['exclude_cdn'] : array();
		$lazy_load_by_px = !empty($this->settings['lazy_load_px']) ? (int)$this->settings['lazy_load_px'] : 200;
        $google_fonts_delay_load = !empty($this->settings['google_fonts_delay_load']) ? $this->settings['google_fonts_delay_load']*1000 : 2000;
        $script = 'var w3_is_mobile='.(!empty($this->add_settings['is_mobile']) ? 1 : 0).';var w3_lazy_load_by_px='.$lazy_load_by_px.';var blank_image_webp_url = "'. (($enable_cdn && !in_array('.png',$exclude_cdn_arr)) ? str_replace($this->add_settings['wp_site_url'],$this->add_settings['image_home_url'],$this->add_settings['upload_base_url']): $this->add_settings['upload_base_url']).'/blank.pngw3.webp";var google_fonts_delay_load = '.$google_fonts_delay_load.';var w3_upload_path="'.$this->add_settings['upload_path'].'"; var w3_webp_path="'.$this->add_settings['webp_path'].'";var w3_mousemoveloadimg = false;var w3_page_is_scrolled = false;var w3_lazy_load_js = '.(!empty($this->settings['load_combined_js']) && $this->settings['load_combined_js'] == 'after_page_load' ? 1 : 0).';';
		if(!empty($this->settings['exclude_page_from_load_combined_js']) && $this->w3_check_if_page_excluded($this->settings['exclude_page_from_load_combined_js'])){
			$script.='var w3_excluded_js=1;';
        }else{
			$script.='var w3_excluded_js=0;';
		}
		return $script.file_get_contents(W3SPEEDSTER_PLUGIN_DIR.'assets/js/script-load.min.js');
	}
	function w3_lazy_load_images(){
		
		$inner_script_optimizer = 'function w3_to_webp(elementImg) {
			for (var ig = 0; ig < elementImg.length; ig++) {
				if (elementImg[ig].getAttribute("data-src") != null && elementImg[ig].getAttribute("data-src") != "") {
					var datasrc = elementImg[ig].getAttribute("data-src");
					elementImg[ig].setAttribute("data-src", datasrc.replace("w3.webp", "").replace(w3_webp_path, w3_upload_path));
				}
				if (elementImg[ig].getAttribute("data-srcset") != null && elementImg[ig].getAttribute("data-srcset") != "") {
					var datasrcset = elementImg[ig].getAttribute("data-srcset");
					elementImg[ig].setAttribute("data-srcset", datasrcset.replace(/w3.webp/g, "").split(w3_webp_path).join(w3_upload_path));
				}
				if (elementImg[ig].src != null && elementImg[ig].src != "") {
					var src = elementImg[ig].src;
					elementImg[ig].src = src.replace("w3.webp", "").replace(w3_webp_path, w3_upload_path);
				}
				if (elementImg[ig].srcset != null && elementImg[ig].srcset != "") {
					var srcset = elementImg[ig].srcset;
					elementImg[ig].srcset = srcset.replace(/w3.webp/g, "").split(w3_webp_path).join(w3_upload_path);
				}
			}
		}

		function fixwebp() {
			if (!w3_hasWebP) {
				var elementNames = ["*"];
				w3_to_webp(document.querySelectorAll("img[data-src$=\'w3.webp\']"));
				w3_to_webp(document.querySelectorAll("img[src$=\'w3.webp\']"));
				elementNames.forEach(function(tagName) {
					var tags = document.getElementsByTagName(tagName);
					var numTags = tags.length;
					for (var i = 0; i < numTags; i++) {
						var tag = tags[i];
						var style = tag.currentStyle || window.getComputedStyle(tag, false);
						var bg = style.backgroundImage;
						if (bg.match("w3.webp")) {
							if (document.all) {
								tag.style.setAttribute("cssText", ";background-image: " + bg.replace("w3.webp", "").replace(w3_webp_path, w3_upload_path) + " !important;");
							} else {
								tag.setAttribute("style", tag.getAttribute("style") + ";background-image: " + bg.replace("w3.webp", "").replace(w3_webp_path, w3_upload_path) + " !important;");
							}
						}
					}
				});
			}
		}

		function w3_change_webp() {
			if (bg.match("w3.webp")) {
				var style1 = {};
				if (document.all) {
					tag.style.setAttribute("cssText", "background-image: " + bg.replace("w3.webp", "").replace(w3_webp_path, w3_upload_path) + " !important");
					style1 = tag.currentStyle || window.getComputedStyle(tag, false);
				} else {
					tag.setAttribute("style", "background-image: " + bg.replace("w3.webp", "").replace(w3_webp_path, w3_upload_path) + " !important");
					style1 = tag.currentStyle || window.getComputedStyle(tag, false);
				}
			}
		}
		var w3_hasWebP = false,w3_bglazyload=1;
		(function() {
			var img = new Image();
			img.onload = function() {
				w3_hasWebP = !!(img.height > 0 && img.width > 0);
			};
			img.onerror = function() {
				w3_hasWebP = false;
				fixwebp();
			};
			img.src = blank_image_webp_url;
		})();
		function w3_events_on_end_js(){
			const lazy_bg_style = document.getElementById("w3_bg_load");
			lazy_bg_style.remove();
			w3_bglazyload = 0;
			lazyloadimages(0);
		}
		function w3_start_img_load() {
			var top = this.scrollY;
			lazyloadimages(top);
			lazyloadiframes(top);
		}

		function w3_events_on_start_js() {
			var lazyvideos = document.getElementsByTagName("videolazy");
			convert_to_video_tag(lazyvideos);
			w3_start_img_load();
		}
		window.addEventListener("scroll", function(event) {
			w3_start_img_load();
		}, {
			passive: true
		});


		var win_width = screen.availWidth;
		var bodyRectMain = {};
		bodyRectMain.top = 1;
		setInterval(function() {
			lazyloadiframes(top);
		}, 8000);
		setInterval(function() {
			lazyloadimages(0);
			fixwebp();
		}, 3000);
		document.addEventListener("click", function() {
			lazyloadimages(0);
		});

		function getDataUrl(img1, width, height) {
			var myCanvas = document.createElement("canvas");
			var ctx = myCanvas.getContext("2d");
			var img = new Image();
			myCanvas.width = parseInt(width);
			myCanvas.height = parseInt(height);
			ctx.drawImage(img, 0, 0);
			img1.src = myCanvas.toDataURL("image/png");
		}

		function lazyload_img(imgs, bodyRect, window_height, win_width) {
			for (var i = 0; i < imgs.length; i++) {
				if (imgs[i].getAttribute("data-class") == "LazyLoad") {
					var elem = imgs[i],
						elemRect = imgs[i].getBoundingClientRect();
					if (elemRect.top != 0 && (elemRect.top - (window_height - bodyRect.top)) < w3_lazy_load_by_px) {
						compStyles = window.getComputedStyle(imgs[i]);
						if (compStyles.getPropertyValue("opacity") == 0) {
							continue;
						}
						if (elem.tagName == "IFRAMELAZY") {
							var elem = document.createElement("iframe");
							var index;
							for (index = imgs[i].attributes.length - 1; index >= 0; --index) {
								elem.attributes.setNamedItem(imgs[i].attributes[index].cloneNode());
							}
							imgs[i].parentNode.replaceChild(elem, imgs[i]);
						}
						var src = elem.getAttribute("data-src") ? elem.getAttribute("data-src") : elem.src;
						var srcset = elem.getAttribute("data-srcset") ? elem.getAttribute("data-srcset") : "";
						if (!srcset) {
							elem.onload = function() {
								this.setAttribute("data-done", "Loaded");
								if (typeof(w3speedup_after_iframe_img_load) == "function") {
									w3speedup_after_iframe_img_load(this);
								}
							}
						}
						elem.src = src;
						if (srcset != null & srcset != "") {
							elem.srcset = srcset;
						}
						delete elem.dataset.class;
					} 
				}
			}
		}
		function w3_load_dynamic_blank_img(imgs){
			for (var i = 0; i < imgs.length; i++) {
				if (imgs[i].getAttribute("data-class") == "LazyLoad") {
					var blanksrc = imgs[i].src;
					if (typeof(blanksrc) != "undefined" && blanksrc.indexOf("data:") == -1) {
						if (imgs[i].getAttribute("width") != null && imgs[i].getAttribute("height") != null) {
							var width = parseInt(imgs[i].getAttribute("width"));
							var height = parseInt(imgs[i].getAttribute("height"));
							getDataUrl(imgs[i], width, height);
						}
					}
				}
			}
		}

		function convert_to_video_tag(imgs) {
			const t = imgs.length > 0 ? imgs[0] : "";
			if (t) {
				delete imgs[0];
				var newelem = document.createElement("video");
				var index;
				for (index = t.attributes.length - 1; index >= 0; --index) {
					newelem.attributes.setNamedItem(t.attributes[index].cloneNode());
				}
				newelem.innerHTML = t.innerHTML;
				t.parentNode.replaceChild(newelem, t);
				if (typeof(newelem.getAttribute("data-poster")) == "string") {
					newelem.setAttribute("poster", newelem.getAttribute("data-poster"));
				}
				convert_to_video_tag(imgs);
			}
		}

		function lazyload_video(imgs, bodyRect, top, window_height, win_width) {
			for (var i = 0; i < imgs.length; i++) {
				var elem = imgs[i], elemRect = imgs[i].getBoundingClientRect();
				if (elemRect.top != 0 && (elemRect.top - (window_height - bodyRect.top)) < w3_lazy_load_by_px) {
					if (typeof(imgs[i].getElementsByTagName("source")[0]) == "undefined") {
						lazyload_video_source(imgs[i], top, window_height, win_width, elemRect, bodyRect);
					} else {
						var sources = imgs[i].getElementsByTagName("source");
						for (var j = 0; j < sources.length; j++) {
							var source = sources[j];
							lazyload_video_source(source, top, window_height, win_width, elemRect, bodyRect);
						}
					}
				}
			}
		}

		function lazyload_video_source(source, top, window_height, win_width, elemRect, bodyRect) {
			if (typeof source != "undefined" && source.getAttribute("data-class") == "LazyLoad") {
				if (elemRect.top != 0 && (elemRect.top - (window_height - bodyRect.top)) < w3_lazy_load_by_px) {
					var src = source.getAttribute("data-src") ? source.getAttribute("data-src") : source.src;
					var srcset = source.getAttribute("data-srcset") ? source.getAttribute("data-srcset") : "";
					if (source.srcset != null & source.srcset != "") {
						source.srcset = srcset;
					}
					if (typeof(source.getElementsByTagName("source")[0]) == "undefined") {
						if (source.tagName == "SOURCE") {
							source.parentNode.src = src;
							source.parentNode.load();
							if (source.parentNode.getAttribute("autoplay") !== null) {
								source.parentNode.play();
							}
						} else {
							source.src = src;
							source.load();
							if (source.getAttribute("autoplay") !== null) {
								source.play();
							}
						}
					} else {
						source.parentNode.src = src;
					}
					delete source.dataset.class;
					source.setAttribute("data-done", "Loaded");
				}
			}
		}
		function lazyload_imgbgs(imgbgs, bodyRect, window_height, win_width){
			for (var i = 0; i < imgbgs.length; i++) {
				var elem = imgbgs[i],
					elemRect = imgbgs[i].getBoundingClientRect(),
					offset = elemRect.top - bodyRect.top;
				if ((elemRect.top - (window_height - bodyRect.top)) < w3_lazy_load_by_px) {
					elem.classList.add("w3_bg");
				}
			}
		}
		function lazyloadimages(top) {
			var imgs = document.querySelectorAll("img[data-class=LazyLoad]");
			var imgbgs = document.querySelectorAll("div:not(.w3_js), section:not(.w3_js), iframelazy:not(.w3_js)");
			var sources = document.getElementsByTagName("video");
			var sources_audio = document.getElementsByTagName("audio");
			var bodyRect = document.body.getBoundingClientRect();
			var window_height = window.innerHeight;
			var win_width = screen.availWidth;
			if (typeof(load_dynamic_img) != "undefined") {
				w3_load_dynamic_blank_img(imgs);
				delete load_dynamic_img;
			}
			if(w3_bglazyload && ((bodyRect.top<50 && bodyRectMain.top == 1) || Math.abs(bodyRectMain.top) - Math.abs(bodyRect.top) < -50 || Math.abs(bodyRectMain.top) - Math.abs(bodyRect.top) > 50)){
				bodyRectMain = bodyRect;
				lazyload_imgbgs(imgbgs, bodyRect, window_height, win_width);
			}
			lazyload_img(imgs, bodyRect, window_height, win_width);
			lazyload_video(sources, bodyRect, top, window_height, win_width);
			lazyload_video(sources_audio, bodyRect, top, window_height, win_width);
		}
		lazyloadimages(0);

		function lazyloadiframes(top) {
			var bodyRect = document.body.getBoundingClientRect();
			var window_height = window.innerHeight;
			var win_width = screen.availWidth;
			var iframes = document.querySelectorAll("iframelazy[data-class=LazyLoad]");
			lazyload_img(iframes, bodyRect, window_height, win_width);
		}';
        $custom_js_path = $this->w3_get_cache_path('all-js').'/wnw-custom-inner-js.js';
        if(!is_file($custom_js_path)){
            $this->w3_create_file($custom_js_path,$this->w3_compress_js($inner_script_optimizer));
        }
        return file_get_contents($custom_js_path);
    
    }
}