=== W3SPEEDSTER ===
Contributors: W3speedster
Tags: w3speedster, website speed, page speed, webp, lazy loading, css minification, js minification, cdn, image optimization, minify html, cache, fast, http cache, gtmetrix, pingdom, psi, google, google rank, google page speed, mod pagespeed, htaccess, aws, elasticache, apache, varnish, xcache, apc, eacclerator, wincache, wp minify, bwp minify, performance, caching, speed up website, wp optimization, wp speed optimization plugin, wp cache,  quick cache, lite cache, hyper cache, db cache reloaded fix, wp green cache, aoi cache & performance, generate cache, cash, wp cache, web performance optimization, performance, page cache, css cache, js cache, db cache, disk cache, disk caching, database cache, http compression, cdn, compress, optimize, optimizer, plugin
Version: 7.18
Tested up to: 6.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
<a href="https://w3speedster.com/">W3speedster</a> W3Speedster is a full page optimization plugin for wordpress that can dramaticaly speed up your website. 

<h4> Note: </h4>
W3speedster is a super fast WordPress Speed Optimization plugin, best used for fixing your slow & lagging WordPress website. This comes lightweight and offers you a quick plugin setup that delivers quicker results. It is built to trigger the heavier elements of your website such as image optimization, CSS minification, and JS minification. 

<h4> Requirements: </h4>

* Wordpress version greater than 5.5     
* Php minimum version required 5.6 
* Writable .htaccess, wp-config.php (manual work around available)
* Writable wp-content (manual work around available)


== Installation ==

1. Upload `W3SPEEDSTER` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to "Settings -> W3speedster" area for setting panel.  

<h4> SETTINGS PANES: </h4>

* GENERAL TAB
    License Key
    CDN URL
    Lazy Loading
    WebP Support
    Image Quality Control
    Excluded Pages
* CSS TAB
    CSS Minification
    Generates Critical CSS
    Force Lazyload Link Tag CSS
    Generates custom CSS
* JAVASCRIPT TAB
    JavaScript Minification
    Exclude JavaScript tags
    Delay JavaScript tags
    Lazy Load JavaScript
    Exclude JavaScript tags
* CACHE TAB
    Delete js/css cache
    Delete Critical CSS
* IMAGE SETTINGS
    Image Optimization


== Free Version ==
* Critical CSS for only homepage will be generated.
* Starting 500 images will be optimized.
* Automated Features:
    - Enabling WebP support
    - Image Quality control
    - Lazy Loading
    - CSS Minification
    - JS Minification
    - Combining of inline and 3rd party scripts
    - Combining Google Fonts

== Pro Version ==
* Unlimited critical css will be generated for the site.
* Unlimited images will be optimized.


== Frequently asked questions ==
= Who is W3Speedster for?
W3Speedster is for anyone with a WordPress website! It works for all large and small sites, no matter what the type. From a simple blog to an online store, W3Speedster will speed up the loading time! It is easy enough for non-technical WordPress users, but extensible enough that seasoned developers can customize it to their liking.

= What are the requirements for W3Speedster?
A minimum of PHP 5.6 is required. 
W3Speedster will work on any of these servers: Apache (with mod_rewrite, mod_expires, mod_deflate), NGINX, Litespeed or Windows. “Pretty” permalinks in WordPress are required.

= Do I need coding know-how to use W3Speeedster?
No, not at all! W3Speedster is the only WordPress performance optimization plugin which integrates over 80% of web performance best practices. This means that you only need to install it, activate it, and make a few minor adjustments that you need: W3Speedster will automatically start optimizing your WordPress website, with no need to tweak the code.

= Do you offer support if I need help? 
Yes, the W3Speedster team is here to help you! Contact us any time and we’ll be happy to assist. You can find our contact information in the “Need Support” box in W3Speedster settings in WordPress.

= Can I use W3Speedster on client sites?
You need to purchase a license for your client’s site. You can also contact us for bulk discounts.
