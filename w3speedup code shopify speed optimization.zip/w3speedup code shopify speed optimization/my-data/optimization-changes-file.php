#Remove critical css from server
https://cloud.w3speedup.com/optimize/css/delete-css.php?url=&key=

#Check critical css file name
?w3_get_css_post_type=1

#Check critical css error
https://cloud.w3speedup.com/optimize/css/critical-css/abc.com/style.css

#Reset image optimization
&reset=1

#Lazyload Images
base64
logo
rev-slidebg
no-lazy
facebook
googletagmanager

#Exclude pages from Optimization
wp-login.php
/cart/
/checkout/

#Force lazy load link tag css
awesome
dashicons
eicons
typekit

#Exclude Inline Javascript from combine
google-analytics
hbspt
/* <![CDATA[ */

#SVG Fonts
@font-face {
font-family: '';
src: url('FontAwesome.eot?#iefix') format('embedded-opentype'),
url('') format('woff2');
font-weight: normal;
font-style: normal;
font-display:swap;	
}

#Src Replace
if(document.querySelector('.image.responsive img') != null)
document.querySelectorAll('.image.responsive img').forEach(function(index){
index.setAttribute('src',index.getAttribute('data-src'));
})

if(document.querySelector('.upb_bg_img') != null)document.querySelector('.upb_bg_img').style.background = document.querySelector('.upb_bg_img').getAttribute('data-ultimate-bg');

#Add in custom js in Thrive theme  
jQuery(window).trigger('tcb_after_dom_ready');

#Change all image in webp
function w3_disable_htaccess_wepb(){
   return true;
}

#Convert all image in 595xh in mobile
function w3speedup_after_optimization($html){
	if(wp_is_mobile()){
		$html = preg_replace('/(url\()(\S*)(\.jpgw3.webp)/i', '$1$2-595xh$3', $html);
		$html = preg_replace('/(url\()(\S*)(\.jpegw3.webp)/i', '$1$2-595xh$3', $html);
        $html = preg_replace('/(url\()(\S*)(\.pngw3.webp)/i', '$1$2-595xh$3', $html);
	}
	return $html;
}

#Before Optimization
function w3speedup_before_start_optimization($html){
		$html = str_replace(array(""),array(""), $html);
	return $html;
}

#After Optimization
function w3speedup_after_optimization($html){
		$html = str_replace(array(""),array(""), $html);
	return $html;
}

#Customize Critical Css
function w3speedup_customize_critical_css($critical_css){
	$critical_css = str_replace(array(''),array(''),$critical_css);
	return $critical_css;
}

#Disable srcset
function w3_disable_srcset{
   return true;
}

#Internal JS Customize
function w3speedup_internal_js_customize($html,$path){
   	if(strpos($path,'/wp-content/themes/adifier-child/js/single-advert.js') !== false){  
        $html = str_replace('$(window).load(function(){','setTimeout ( function() {',$html);		
	}
   return $html;
}

#Inner JS Customize
function w3speedup_inner_js_customize($html){
   if(strpos($html,'//unique word from script//') !== false){
      $html = str_replace('','',$html);
   }
   return $html;
}

#Separate Critical CSS
function w3_create_separate_critical_css_of_post_type(){
return array('page','post');
}

#Disable Lazyload Image on particluar page or post
function w3speedup_customize_main_settings($add_settings){
	if(is_page(page-id-9269)){
		$add_settings['lazy_load'] = 0;
	}
	return $add_settings;
}

#Rev Slider Functions
#One
function w3speedup_inner_js_customize($html){
	global $load_slider;
	if(empty($load_slider)){
		$load_slider = 1;
	}
	if(strpos($html,'revinit_revslider') !== false || strpos($html,'rsCustomAjaxContent_Once') !== false){	 
		$html = str_replace('if (document.readyState','var load_slider'.$load_slider.' = setInterval(function(){if(typeof(jQuery) == "function"){clearInterval(load_slider'.$load_slider.');}else{return;}var timeout1 = window.innerWidth > 768 ? 10 : 1500;setTimeout(function(){if (document.readyState',$html).'},timeout1);},100);';	
	}
	$load_slider++;
	return $html;
}

#Two
function w3speedup_inner_js_customize($html){
	global $load_slider;
	if(empty($load_slider)){
		$load_slider = 1;
	}
	if(strpos($html,'setREVStartSize({c:') !== false || strpos($html,'rsCustomAjaxContent_Once') !== false){	 
		$html = str_replace('jQuery(function() {','var load_slider'.$load_slider.' = setInterval(function(){if(typeof(jQuery) == "function" && typeof(jQuery.fn.revolution) == "function"){clearInterval(load_slider'.$load_slider.');}else{return;}var timeout1 = window.innerWidth > 768 ? 10 : 1500;setTimeout(function(){setTimeout(function() {',$html).'},timeout1);},100);';	
	}
	$load_slider++;
	return $html;
}

#Three
function w3speedup_inner_js_customize($html){
	global $load_slider;
	if(empty($load_slider)){
		$load_slider = 1;
	}
	if(strpos($html,'revinit_revslider') !== false || strpos($html,'rsCustomAjaxContent_Once') !== false){	 
		$html = str_replace(array('jQuery(function() {','if (document.readyState'),array('setTimeout(function(){','var load_slider'.$load_slider.' = setInterval(function(){if(typeof(jQuery) == "function" && typeof(jQuery.fn.revolution) == "function"){clearInterval(load_slider'.$load_slider.');}else{return;}var timeout1 = window.innerWidth > 768 ? 10 : 2500;setTimeout(function(){if (document.readyState'),$html).'},timeout1);},100);';	
	}
	$load_slider++;
	return $html;
}

#Four
function w3speedup_inner_js_customize($html){
		global $load_slider;
	if(empty($load_slider)){
		$load_slider = 1;
	}
	if(strpos($html,'.revolutionInit({') !== false || strpos($html,'rsCustomAjaxContent_Once') !== false){	 
		$html = 'var load_slider'.$load_slider.' = setInterval(function(){if(typeof(jQuery) == "function" && typeof(window.RS_MODULES) == "object" && typeof(jQuery.fn.revolution) == "object" && typeof(jQuery.fn.revolutionInit) == "function" ){clearInterval(load_slider'.$load_slider.');}else{return;}var timeout1 = window.innerWidth > 768 ? 10 : 2500;setTimeout(function(){'.$html.'},timeout1);},100);';
		$html = str_replace('window.rev', 'rev', $html);
	}
	$load_slider++;
	return $html;
}

#Remove jquery-core-js from mobile
function w3speedup_exclude_javascript_filter($exclude_js,$script_obj,$script){
	if(wp_is_mobile()){
        if(strpos($script,'jquery-core-js') !== false || strpos($script,'/revslider/') !== false){
			return 0;
        }
    }
    return $exclude_js;
}

#Exclude Javascript
/revslider/ defer
jquery-core-js defer

#Exclude  Inline JS
setREVStartSize
revslider

#Rev slider rs6.css Compressed CSS
rs-modal{position:fixed!important;z-index:9999999!important;pointer-events:none!important}rs-modal.rs-modal-auto{top:auto;bottom:auto;left:auto;right:auto}rs-modal.rs-modal-fullscreen,rs-modal.rs-modal-fullwidth{top:0;left:0;width:100%;height:100%}rs-modal rs-fullwidth-wrap{position:absolute;top:0;left:0;height:100%}rs-module-wrap.rs-modal{display:none;max-height:100%!important;overflow:auto!important;pointer-events:auto!important}rs-modal-cover{width:100%;height:100%;z-index:0;background:0 0;position:absolute;top:0;left:0;cursor:pointer;pointer-events:auto}body>rs-modal-cover{position:fixed;z-index:9999995!important}rs-sbg-px{pointer-events:none}.rs-forcehidden *{visibility:hidden!important}.rs_splitted_lines{display:block;white-space:nowrap!important}#builderView i[class*=" fa-"],#builderView i[class^=fa-],#objectlibrary i[class*=" fa-"],#objectlibrary i[class^=fa-],#rs_overview i[class*=" fa-"],#rs_overview i[class^=fa-],#rs_overview_menu i[class*=" fa-"],#rs_overview_menu i[class^=fa-],#waitaminute i[class*=" fa-"],#waitaminute i[class^=fa-],.rb-modal-wrapper i[class*=" fa-"],.rb-modal-wrapper i[class^=fa-],rs-module i[class*=" fa-"],rs-module i[class^=fa-]{display:inline-block;font:normal normal normal 14px/1 FontAwesome;font-size:inherit;text-rendering:auto;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}#builderView [class*=" fa-"]:before,#builderView [class^=fa-]:before,#objectlibrary [class*=" fa-"]:before,#objectlibrary [class^=fa-]:before,#rs_overview [class*=" fa-"]:before,#rs_overview [class^=fa-]:before,#rs_overview_menu [class*=" fa-"]:before,#rs_overview_menu [class^=fa-]:before,#waitaminute [class*=" fa-"]:before,#waitaminute [class^=fa-]:before,.rb-modal-wrapper [class*=" fa-"]:before,.rb-modal-wrapper [class^=fa-]:before,rs-module [class*=" fa-"]:before,rs-module [class^=fa-]:before{font-family:FontAwesome;font-style:normal;font-weight:400;speak:none;display:inline-block;text-decoration:inherit;width:auto;margin-right:0;text-align:center;font-variant:normal;text-transform:none;line-height:inherit;margin-left:0}#builderView .sr-only,#objectlibrary .sr-only,#rs_overview .sr-only,#rs_overview_menu .sr-only,#waitaminute .sr-only,.rb-modal-wrapper .sr-only,rs-module .sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}#builderView .sr-only-focusable:active,#builderView .sr-only-focusable:focus,#objectlibrary .sr-only-focusable:active,#objectlibrary .sr-only-focusable:focus,#rs_overview .sr-only-focusable:active,#rs_overview .sr-only-focusable:focus,#rs_overview_menu .sr-only-focusable:active,#rs_overview_menu .sr-only-focusable:focus,#waitaminute .sr-only-focusable:active,#waitaminute .sr-only-focusable:focus,.rb-modal-wrapper .sr-only-focusable:active,.rb-modal-wrapper .sr-only-focusable:focus,rs-module .sr-only-focusable:active,rs-module .sr-only-focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}.tp-fullwidth-forcer{z-index:0;pointer-events:none}rs-module-wrap,rs-module-wrap *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}rs-module-wrap{position:relative;z-index:1;width:100%;display:block}.rs-fixedscrollon rs-module-wrap{position:fixed!important;top:0!important;z-index:1000}rs-fw-forcer{display:block;width:100%;pointer-events:none}rs-module{position:relative;overflow:hidden;display:block}rs-pzimg-wrap,rs-sbg,rs-sbg-effectwrap{display:block;pointer-events:none}rs-sbg-effectwrap{position:absolute;top:0;left:0;width:100%;height:100%}rs-sbg-px,rs-sbg-wrap{position:absolute;top:0;left:0;z-index:0;width:100%;height:100%;display:block}a.rs-layer,a.rs-layer:-webkit-any-link{text-decoration:none}a[x-apple-data-detectors]{color:inherit!important;text-decoration:none!important;font-size:inherit!important;font-family:inherit!important;font-weight:inherit!important;line-height:inherit!important}.entry-content rs-module a,rs-module a{box-shadow:none}.rs-ov-hidden{overflow:hidden!important}.rs-forceoverflow,.rs-forceoverflow rs-module,.rs-forceoverflow rs-module-wrap,.rs-forceoverflow rs-slide,.rs-forceoverflow rs-slides{overflow:visible!important}.tp-simpleresponsive img,rs-module img{max-width:none!important;transition:none;margin:0;padding:0;border:none}rs-module .no-slides-text{font-weight:700;text-align:center;padding-top:80px}rs-slide,rs-slide:before,rs-slides{position:absolute;text-indent:0;top:0;left:0}rs-slide,rs-slide:before{display:block;visibility:hidden}.rs-layer .rs-untoggled-content{display:block}.rs-layer .rs-toggled-content{display:none}.rs-tc-active.rs-layer .rs-toggled-content{display:block}.rs-tc-active.rs-layer .rs-untoggled-content{display:none}.rs-layer-video{overflow:hidden}rs-module .rs-layer,rs-module rs-layer{opacity:0;position:relative;visibility:hidden;white-space:nowrap;display:block;-webkit-font-smoothing:antialiased!important;-webkit-tap-highlight-color:transparent;-moz-osx-font-smoothing:grayscale;z-index:1}rs-layer-wrap,rs-mask,rs-module .rs-layer,rs-module img,rs-module-wrap{-moz-user-select:none;-khtml-user-select:none;-webkit-user-select:none;-o-user-select:none}.wpb_text_column rs-module rs-mask-wrap .rs-layer,.wpb_text_column rs-module rs-mask-wrap :last-child,rs-module rs-mask-wrap .rs-layer,rs-module rs-mask-wrap :last-child{margin-bottom:0}.rs-svg svg{width:100%;height:100%;position:relative;vertical-align:top}.rs-layer,.rs-layer *,rs-alyer *,rs-layer{outline:0!important}rs-carousel-wrap{cursor:url(openhand.cur),move}rs-carousel-wrap.dragged{cursor:url(closedhand.cur),move}rs-carousel-wrap{position:absolute;overflow:hidden;width:100%;height:100%;top:0;left:0}rs-carousel-space{clear:both;display:block;width:100%;height:1px;position:relative;margin-bottom:-1px}.tp_inner_padding{box-sizing:border-box;max-height:none!important}.rs-layer.rs-selectable{-moz-user-select:all;-khtml-user-select:all;-webkit-user-select:all;-o-user-select:all}rs-px-mask{overflow:hidden;display:block;width:100%;height:100%;position:relative}rs-module audio,rs-module embed,rs-module iframe,rs-module object,rs-module video{max-width:none!important;border:none}rs-bg-elem{position:absolute;top:0;left:0;width:100%;height:100%;z-index:0;display:block;pointer-events:none}.tp-blockmask,.tp-blockmask_in,.tp-blockmask_out{position:absolute;top:0;left:0;width:100%;height:100%;background:#fff;z-index:1000;transform:scaleX(0) scaleY(0)}rs-zone{position:absolute;width:100%;left:0;box-sizing:border-box;min-height:50px;font-size:0}rs-cbg-mask-wrap,rs-column,rs-layer-wrap,rs-loop-wrap,rs-mask-wrap,rs-parallax-wrap,rs-row-wrap{display:block;visibility:hidden}rs-column-wrap>rs-loop-wrap{z-index:1}rs-cbg-mask-wrap,rs-layer-wrap,rs-mask-wrap{transform-style:flat;perspective:10000px}rs-mask-wrap{overflow:hidden}rs-fullwidth-wrap{position:relative;width:100%;height:auto;display:block}.rev_row_zone_top{top:0}.rev_row_zone_bottom{bottom:0}rs-column-wrap .rs-parallax-wrap{vertical-align:top}.rs-layer img,rs-layer img{vertical-align:top}rs-row,rs-row.rs-layer{display:table;position:relative;width:100%!important;table-layout:fixed;box-sizing:border-box;vertical-align:top;height:auto;font-size:0}rs-column-wrap{display:table-cell;position:relative;vertical-align:top;height:auto;box-sizing:border-box;font-size:0}rs-column{box-sizing:border-box;display:block;position:relative;width:100%!important;height:auto!important;white-space:normal!important}rs-cbg-mask-wrap{position:absolute;z-index:0;box-sizing:border-box}rs-column-bg{position:absolute;z-index:0;box-sizing:border-box;width:100%;height:100%}.rs-pelock *{pointer-events:none!important}rs-column .rs-parallax-wrap,rs-column rs-loop-wrap,rs-column rs-mask-wrap{text-align:inherit}rs-column rs-mask-wrap{display:inline-block}rs-column .rs-parallax-wrap,rs-column .rs-parallax-wrap rs-loop-wrap,rs-column .rs-parallax-wrap rs-mask-wrap{position:relative!important;left:auto!important;top:auto!important;line-height:0}rs-column .rev_layer_in_column,rs-column .rs-parallax-wrap,rs-column .rs-parallax-wrap rs-loop-wrap,rs-column .rs-parallax-wrap rs-mask-wrap{vertical-align:top}.rev_break_columns{display:block!important}.rev_break_columns rs-column-wrap.rs-parallax-wrap{display:block!important;width:100%!important}.rev_break_columns rs-column-wrap.rs-parallax-wrap.rs-layer-hidden,.rs-layer-audio.rs-layer-hidden,.rs-layer.rs-layer-hidden,.rs-parallax-wrap.rs-layer-hidden,.tp-forcenotvisible,.tp-hide-revslider,rs-column-wrap.rs-layer-hidden,rs-row-wrap.rs-layer-hidden{visibility:hidden!important;display:none!important}.rs-layer.rs-nointeraction,rs-layer.rs-nointeraction{pointer-events:none!important}rs-static-layers{position:absolute;z-index:101;top:0;left:0;display:block;width:100%;height:100%;pointer-events:none}rs-static-layers.rs-stl-back{z-index:0}.rs-layer rs-fcr{width:0;height:0;border-left:40px solid transparent;border-right:0 solid transparent;border-top:40px solid #00a8ff;position:absolute;right:100%;top:0}.rs-layer rs-fcrt{width:0;height:0;border-left:40px solid transparent;border-right:0 solid transparent;border-bottom:40px solid #00a8ff;position:absolute;right:100%;top:0}.rs-layer rs-bcr{width:0;height:0;border-left:0 solid transparent;border-right:40px solid transparent;border-bottom:40px solid #00a8ff;position:absolute;left:100%;top:0}.rs-layer rs-bcrt{width:0;height:0;border-left:0 solid transparent;border-right:40px solid transparent;border-top:40px solid #00a8ff;position:absolute;left:100%;top:0}.tp-layer-inner-rotation{position:relative!important}img.tp-slider-alternative-image{width:100%;height:auto}.noFilterClass{filter:none!important}rs-bgvideo{position:absolute;top:0;left:0;width:100%;height:100%;visibility:hidden;z-index:0;display:block}.rs-layer.coverscreenvideo{width:100%;height:100%;top:0;left:0;position:absolute}.rs-layer.rs-fsv{left:0;top:0;position:absolute;width:100%;height:100%}.rs-layer.rs-fsv audio,.rs-layer.rs-fsv iframe,.rs-layer.rs-fsv iframe audio,.rs-layer.rs-fsv iframe video,.rs-layer.rs-fsv video{width:100%!important;height:100%!important;display:none}.fullcoveredvideo audio,.rs-fsv audio .fullcoveredvideo video,.rs-fsv video{background:#000}.fullcoveredvideo rs-poster{background-position:center center;background-size:cover;width:100%;height:100%;top:0;left:0}.videoisplaying .html5vid rs-poster{display:none}.tp-video-play-button{background:#000;background:rgba(0,0,0,.3);border-radius:5px;position:absolute;top:50%;left:50%;color:#fff;z-index:3;margin-top:-25px;margin-left:-25px;line-height:50px!important;text-align:center;cursor:pointer;width:50px;height:50px;box-sizing:border-box;display:inline-block;vertical-align:top;z-index:4;opacity:0;transition:opacity .3s ease-out!important}.rs-audio .tp-video-play-button{display:none!important}.rs-layer .html5vid{width:100%!important;height:100%!important}.tp-video-play-button i{width:50px;height:50px;display:inline-block;text-align:center!important;vertical-align:top;line-height:50px!important;font-size:30px!important}.rs-layer:hover .tp-video-play-button{opacity:1;display:block}.rs-layer .tp-revstop{display:none;width:15px;border-right:5px solid #fff!important;border-left:5px solid #fff!important;transform:translateX(50%) translateY(50%);height:20px;margin-left:11px!important;margin-top:5px!important}.videoisplaying .revicon-right-dir{display:none}.videoisplaying .tp-revstop{display:block}.videoisplaying .tp-video-play-button{display:none}.fullcoveredvideo .tp-video-play-button{display:none!important}.rs-fsv .rs-fsv audio{object-fit:contain!important}.rs-fsv .rs-fsv video{object-fit:contain!important}.rs-fsv .fullcoveredvideo audio{object-fit:cover!important}.rs-fsv .fullcoveredvideo video{object-fit:cover!important}.rs-fullvideo-cover{width:100%;height:100%;top:0;left:0;position:absolute;background:0 0;z-index:5}.rs-nolc .tp-video-play-button,rs-bgvideo audio::-webkit-media-controls,rs-bgvideo video::-webkit-media-controls,rs-bgvideo video::-webkit-media-controls-start-playback-button{display:none!important}.rs-audio .tp-video-controls{opacity:1!important;visibility:visible!important}rs-module div.rs-layer,rs-module h1.rs-layer,rs-module h2.rs-layer,rs-module h3.rs-layer,rs-module h4.rs-layer,rs-module h5.rs-layer,rs-module h6.rs-layer,rs-module p.rs-layer,rs-module span.rs-layer{margin:0;padding:0;margin-block-start:0;margin-block-end:0;margin-inline-start:0;margin-inline-end:0}rs-module h1.rs-layer:before,rs-module h2.rs-layer:before,rs-module h3.rs-layer:before,rs-module h4.rs-layer:before,rs-module h5.rs-layer:before,rs-module h6.rs-layer:before{content:none}rs-dotted{background-repeat:repeat;width:100%;height:100%;position:absolute;top:0;left:0;z-index:3;display:block;pointer-events:none}rs-sbg-wrap rs-dotted{z-index:31}rs-dotted.twoxtwo{background:url(../assets/gridtile.png)}rs-dotted.twoxtwowhite{background:url(../assets/gridtile_white.png)}rs-dotted.threexthree{background:url(../assets/gridtile_3x3.png)}rs-dotted.threexthreewhite{background:url(../assets/gridtile_3x3_white.png)}.tp-shadowcover{width:100%;height:100%;top:0;left:0;background:#fff;position:absolute;z-index:-1}.tp-shadow1{box-shadow:0 10px 6px -6px rgba(0,0,0,.8)}.tp-shadow2:after,.tp-shadow2:before,.tp-shadow3:before,.tp-shadow4:after{z-index:-2;position:absolute;content:"";bottom:10px;left:10px;width:50%;top:85%;max-width:300px;background:0 0;box-shadow:0 15px 10px rgba(0,0,0,.8);transform:rotate(-3deg)}.tp-shadow2:after,.tp-shadow4:after{transform:rotate(3deg);right:10px;left:auto}.tp-shadow5{position:relative;box-shadow:0 1px 4px rgba(0,0,0,.3),0 0 40px rgba(0,0,0,.1) inset}.tp-shadow5:after,.tp-shadow5:before{content:"";position:absolute;z-index:-2;box-shadow:0 0 25px 0 rgba(0,0,0,.6);top:30%;bottom:0;left:20px;right:20px;border-radius:100px/20px}.rev-btn,.rev-btn:visited{outline:0!important;box-shadow:none;text-decoration:none!important;box-sizing:border-box;cursor:pointer}.rev-btn.rev-uppercase,.rev-btn.rev-uppercase:visited{text-transform:uppercase}.rev-btn i{font-size:inherit;font-weight:400;position:relative;top:0;transition:opacity .2s ease-out,margin .2s ease-out;margin-left:0;line-height:inherit}.rev-btn.rev-hiddenicon i{font-size:inherit;font-weight:400;position:relative;top:0;transition:opacity .2s ease-out,margin .2s ease-out;opacity:0;margin-left:0!important;width:0!important}.rev-btn.rev-hiddenicon:hover i{opacity:1!important;margin-left:10px!important;width:auto!important}.rev-burger{position:relative;box-sizing:border-box;padding:22px 14px 22px 14px;border-radius:50%;border:1px solid rgba(51,51,51,.25);-webkit-tap-highlight-color:transparent;-webkit-tap-highlight-color:transparent;cursor:pointer}.rev-burger span{display:block;width:30px;height:3px;background:#333;transition:.7s;pointer-events:none;transform-style:flat!important}.rev-burger span:nth-child(2){margin:3px 0}#dialog_addbutton .rev-burger:hover :first-child,.open .rev-burger :first-child,.open.rev-burger :first-child,.quick_style_example_wrap .rev-burger:hover :first-child{transform:translateY(6px) rotate(-45deg)}#dialog_addbutton .rev-burger:hover :nth-child(2),.open .rev-burger :nth-child(2),.open.rev-burger :nth-child(2),.quick_style_example_wrap .rev-burger:hover :nth-child(2){transform:rotate(-45deg);opacity:0}#dialog_addbutton .rev-burger:hover :last-child,.open .rev-burger :last-child,.open.rev-burger :last-child,.quick_style_example_wrap .rev-burger:hover :last-child{transform:translateY(-6px) rotate(-135deg)}.rev-burger.revb-white{border:2px solid rgba(255,255,255,.2)}.rev-b-span-light span,.rev-burger.revb-white span{background:#fff}.rev-burger.revb-whitenoborder{border:0}.rev-burger.revb-whitenoborder span{background:#fff}.rev-burger.revb-darknoborder{border:0}.rev-b-span-dark span,.rev-burger.revb-darknoborder span{background:#333}.rev-burger.revb-whitefull{background:#fff;border:none}.rev-burger.revb-whitefull span{background:#333}.rev-burger.revb-darkfull{background:#333;border:none}.rev-burger.revb-darkfull span{background:#fff}@keyframes rev-ani-mouse{0%{opacity:1;top:29%}15%{opacity:1;top:70%}50%{opacity:0;top:70%}100%{opacity:0;top:29%}}.rev-scroll-btn{display:inline-block;position:relative;left:0;right:0;text-align:center;cursor:pointer;width:35px;height:55px;box-sizing:border-box;border:3px solid #fff;border-radius:23px}.rev-scroll-btn>*{display:inline-block;line-height:18px;font-size:13px;font-weight:400;color:#7f8c8d;color:#fff;font-family:proxima-nova,"Helvetica Neue",Helvetica,Arial,sans-serif;letter-spacing:2px}.rev-scroll-btn>.active,.rev-scroll-btn>:focus,.rev-scroll-btn>:hover{color:#fff}.rev-scroll-btn>.active,.rev-scroll-btn>:active,.rev-scroll-btn>:focus,.rev-scroll-btn>:hover{opacity:.8}.rev-scroll-btn.revs-fullwhite{background:#fff}.rev-scroll-btn.revs-fullwhite span{background:#333},.rev-scroll-btn.revs-fulldark{background:#333;border:none}.rev-scroll-btn.revs-fulldark span{background:#fff}.rev-scroll-btn span{position:absolute;display:block;top:29%;left:50%;width:8px;height:8px;margin:-4px 0 0 -4px;border-radius:50%;animation:rev-ani-mouse 2.5s linear infinite;background:#fff}.rev-scroll-btn.rev-b-span-dark{border-color:#333}.rev-scroll-btn.rev-b-span-dark span,.rev-scroll-btn.revs-dark span{background:#333}.rev-control-btn{position:relative;display:inline-block;z-index:5;color:#fff;font-size:20px;line-height:60px;font-weight:400;font-style:normal;font-family:Raleway;text-decoration:none;text-align:center;background-color:#000;border-radius:50px;text-shadow:none;background-color:rgba(0,0,0,.5);width:60px;height:60px;box-sizing:border-box;cursor:pointer}.rev-cbutton-dark-sr{border-radius:3px}.rev-cbutton-light{color:#333;background-color:rgba(255,255,255,.75)}.rev-cbutton-light-sr{color:#333;border-radius:3px;background-color:rgba(255,255,255,.75)}.rev-sbutton{line-height:37px;width:37px;height:37px}.rev-sbutton-blue{background-color:#3b5998}.rev-sbutton-lightblue{background-color:#00a0d1}.rev-sbutton-red{background-color:#dd4b39}rs-progress{visibility:hidden;width:100%;height:5px;background:#000;background:rgba(0,0,0,.15);position:absolute;z-index:200;top:0}rs-progress.rs-bottom{top:auto;bottom:0!important;height:5px}.rs-layer img{background:0 0;zoom:1}.rs-layer.slidelink{cursor:pointer;width:100%;height:100%}.rs-layer.slidelink a{width:100%;height:100%;display:block}.rs-layer.slidelink a div{width:3000px;height:1500px;background:url(../assets/coloredbg.png) repeat}.rs-layer.slidelink a span{background:url(../assets/coloredbg.png) repeat;width:100%;height:100%;display:block}.rs-layer .rs-starring{display:inline-block}.rs-layer .rs-starring .star-rating{float:none;display:inline-block;vertical-align:top;color:#ffc321!important}.rs-layer .rs-starring .star-rating,.rs-layer .rs-starring-page .star-rating{position:relative;height:1em;width:5.4em;font-family:star;font-size:1em!important}.rs-layer .rs-starring .star-rating:before,.rs-layer .rs-starring-page .star-rating:before{content:"\73\73\73\73\73";color:#e0dadf;float:left;top:0;left:0;position:absolute}.rs-layer .rs-starring .star-rating span{overflow:hidden;float:left;top:0;left:0;position:absolute;padding-top:1.5em;font-size:1em!important}.rs-layer .rs-starring .star-rating span:before{content:"\53\53\53\53\53";top:0;position:absolute;left:0}


#Elementor frontend.min.js issue
function w3speedup_internal_js_customize($html,$path){
	if(strpos($path,'elementor/assets/js/frontend.min.js') !== false){	   
		$html = str_replace('jQuery((()=>elementorFrontend.init()))','jQuery((function(){return setTimeout(function(){ elementorFrontend.init(); },1000) }))',$html);	
	}
	return $html;
}

#Brahmastra for CF7
function w3speedup_internal_js_customize($html,$path){
   if(strpos($path,'/recaptcha/index.js') !== false){
      $html = str_replace(array('document.addEventListener("DOMContentLoaded",(e=>','))}))'),array('setTimeout(function()','))})'),$html);
   }
   return $html;
}

#Full Width for Page Bakery
#vc_row
if(document.querySelector('.vc_row[data-vc-full-width]') != null ){			
var w = document.querySelector('.vc_row[data-vc-full-width]').offsetWidth;
	var f = document.querySelector('#page').offsetWidth;
				
	var l = (f-w)/2;
	for(i=0;i<document.querySelectorAll('.vc_row[data-vc-full-width]').length;i++){
		document.querySelectorAll('.vc_row[data-vc-full-width]')[i].style.left = '-'+l +"px";
		document.querySelectorAll('.vc_row[data-vc-full-width]')[i].style.paddingRight = ''+l +"px";
		document.querySelectorAll('.vc_row[data-vc-full-width]')[i].style.paddingLeft = ''+l +"px";
		document.querySelectorAll('.vc_row[data-vc-full-width]')[i].style.width= f +"px";		
	}				
}

#vc_section
if(document.querySelector('.vc_section[data-vc-full-width]') != null ){			
var w = document.querySelector('.vc_section[data-vc-full-width]').offsetWidth;
	var f = document.querySelector('.header-area').offsetWidth;
				
	var l = (f-w)/2;
	for(i=0;i<document.querySelectorAll('.vc_section[data-vc-full-width]').length;i++){
		document.querySelectorAll('.vc_section[data-vc-full-width]')[i].style.left = '-'+l +"px";
		document.querySelectorAll('.vc_section[data-vc-full-width]')[i].style.paddingRight = ''+l +"px";
		document.querySelectorAll('.vc_section[data-vc-full-width]')[i].style.paddingLeft = ''+l +"px";
		document.querySelectorAll('.vc_section[data-vc-full-width]')[i].style.width= f +"px";		
	}				
}

#Required CSS
.vc_row {
    position: relative;
}

#One Click Menu
#Console Check
jQuery('.class').click();

#One
var w3_menuclicked = 0;
var w3_menu = document.getElementsByClassName('hamburger-icon')[0];
var w3_html = document.getElementsByTagName('html')[0];
w3_menu.addEventListener("click", function(){
if(!w3_html.classList.contains('w3_js')){
    w3_menuclicked=1;
}
});

jQuery(window).scroll(function(){
if(jQuery.fn.fitVids){jQuery('#main-content').fitVids({});}
});
setTimeout(function(){
if(w3_menuclicked){
w3_menuclicked = 0;
jQuery('.hamburger-icon').click();
}
},600);

#Two
var w3_menuclicked = 0;
var w3_menu = document.getElementsByClassName("dt-mobile-menu-icon");
var w3_html = document.getElementsByTagName('html')[0];
var clickFunction = function() {
    console.log(12222);
    if(!w3_html.classList.contains('w3_js')){
       w3_menuclicked=1;
    }
};
for (var i = 0; i < w3_menu.length; i++) {
    w3_menu[i].addEventListener('click', clickFunction, false);
}

if(w3_menuclicked){
console.log(11111111);
w3_menuclicked = 0;
jQuery('.dt-mobile-menu-icon').trigger('click');
}

#Change data-thumbnail to background image
document.querySelectorAll('.e-gallery-image').forEach(function(elem){
elem.style.background = 'url(' + elem.getAttribute("data-thumbnail") + ')';
})

#Brahmastra CSS

video::-webkit-media-controls {
display: none;
}

left: calc(((100vw - 100%)/-2)) !important;
width: 100vw !important;

.blog .elementor-post__thumbnail img {
    height: auto;
    position: absolute;
    top: calc(50% + 1px);
    left: calc(50% + 1px);
    transform: scale(1.01) translate(-50%,-50%);
    width: calc(100% + 1px);
}

.home #rev_slider_15_1_wrapper {
    background-image: url(https://youthfulbody.co.uk/wp-content/uploads/2021/01/gradientbg-scaled-1.jpg) !important;
    opacity: 1 !important;
    visibility: visible !important;
    background-size: cover !important;
    background-position: center !important;
}

.upb_row_bg {
    position: absolute;
    height: 100%;
    top: 0;
    bottom: 0;
    right: 0;
    z-index: 0;
} 

.elementor-invisible {
    visibility: visible;
}


#x33 -  content: "3";
#x61 -  content: "a";


#slicknav_menu append js
var menu_div = document.createElement("div");                 
var menu_inner = `<div class="slicknav_menu"><a href="#" aria-haspopup="true" tabindex="0" class="slicknav_btn slicknav_collapsed"><span class="slicknav_menutxt">MENU</span><span class="slicknav_icon"><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span></span></a></div>`;        
menu_div.classList.add('slicknav_menu2');
menu_div.innerHTML = menu_inner;                             
document.querySelector('#mobileheader').insertBefore(menu_div,document.querySelector('#mobileheader').firstChild)